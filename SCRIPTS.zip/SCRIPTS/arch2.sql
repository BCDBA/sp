col group# 	format 999      heading 'Group'  
col member 	format a70	heading 'Member' justify c 
col status 	format a10	heading 'Status' justify c	 
col archived	format a10	heading 'Archived' 	 
col fsize 	format 99999 	heading 'Size|(GB)'  
 
select  f.INST_ID,l.group#, 
        member, 
 	archived, 
        l.status, 
        (bytes/1024/1024/1024) fsize 
from    gv$log l, 
	gv$logfile f 
where f.group# = l.group# 
order by 1 
/


 select * from gv$log ;

