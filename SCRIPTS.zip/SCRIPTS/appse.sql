col module for a35 trunc
col ARGUMENT_TEXT for a40 noprint
col action for a20 trunc noprint
col uname for a15 trunc
col event for a40 trunc
col sid head "Sid" form 999999 trunc

select request_id,PARENT_REQUEST_ID ,concurrent_program_id  PROG_ID,s.inst_id,s.sid sid,s.serial# serial,to_char(logon_time,'dd/mm hh24:mi') dt,argument_text,
s.module module,s.action action,user_name uname,s.event,s.sql_id sql_id
from  gv$session s,gv$process p,apps.fnd_concurrent_requests fnd,apps.fnd_user fndu
where p.inst_id = s.inst_id
and p.addr = s.paddr 
and p.spid = fnd.oracle_process_id 
and  fnd.requested_by = fndu.user_id 
and	 fnd.status_code = 'R'
and	 fnd.phase_code = 'R'
order by 1
/



col argument_text for a60 TRUNC print
col request_id for 9999999999
col pc for a2
col sc for a2
col sdt for a15
col edt for a15
col mints for 99999 
col argument_text for a30 trunc
COL CONCURRENT_PROGRAM_NAME FOR A35
COL USER_CONCURRENT_PROGRAM_NAME FOR A40 TRUNC

select 	request_id,PARENT_REQUEST_ID ,phase_code pc,status_code sc,to_char(actual_start_date,'dd/mm hh24:mi:ss') sdt,
	to_char(actual_completion_date,'dd/mm hh24:mi:ss') edt,
	(actual_completion_date-actual_start_date)*(60*24) mints,
	A.concurrent_program_id  CONC_PROG_ID ,argument_text,CONCURRENT_PROGRAM_NAME,USER_CONCURRENT_PROGRAM_NAME
from 	apps.fnd_concurrent_requests A, APPS.FND_CONCURRENT_PROGRAMS_VL B
 where  A.CONCURRENT_PROGRAM_ID = B.CONCURRENT_PROGRAM_ID
and	 A.status_code = 'R'
and	A.phase_code = 'R'
;





col sid head "Sid" form 999999 trunc
col serial# form 99999 trunc head "Ser#"
col username form a15 trunc
col osuser form a15 trunc
col machine form a20 trunc head "Client|Machine"
col program form a15 trunc head "Client|Program"
col APP_USER form a35
col login form a11
col "last call"  form 9999999 trunc head "Last Call|In Secs"
col status form a6 trunc
select inst_id,sid,serial#,substr(username,1,10) username,substr(osuser,1,10) osuser,
	 substr(program||module,1,15) program,substr(machine,1,22) machine,
	 to_char(logon_time,'ddMon hh24:mi') login,
	 last_call_et "last call",status,client_identifier APP_USER,module
from gv$session where client_identifier is not null  and status='ACTIVE' and  client_identifier not in('SYSADMIN')
order by login
/




COLUMN username FORMAT A13
COLUMN OSUSER FORMAT A13
COLUMN event FORMAT A36
COLUMN wait_class FORMAT A13
COLUMN STATE FORMAT A17

SELECT s.inst_id,
       NVL(s.username, '(oracle)') AS username,S.OSUSER,
       s.sid,
       s.serial#,
       s.ROW_WAIT_OBJ#,
       sw.event,
       sw.wait_class,
       sw.wait_time,
       sw.seconds_in_wait,
       sw.state,
       s.SQL_HASH_VALUE,
       s.sql_id,
s.prev_sql_id
FROM   gv$session_wait sw,
       gv$session s
WHERE  s.sid     = sw.sid
AND    s.inst_id = sw.inst_id
AND  sw.wait_class != 'Idle' and client_identifier is not null  and status='ACTIVE' and  client_identifier not in('SYSADMIN')
ORDER BY s.inst_id,sw.event,sw.seconds_in_wait DESC;
