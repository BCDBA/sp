
@@autotask_sql_setup

select * 
from DBA_AUTOTASK_WINDOW_HISTORY
order by window_start_time;

