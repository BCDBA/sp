SELECT distinct description
FROM APPS.fnd_concurrent_requests
WHERE NVL (request_type, 'X')        = 'M'
  CONNECT BY PRIOR parent_request_id = request_id
  START WITH request_id              = &RequestID; 


 SELECT /*+ ORDERED USE_NL(x fcr fcp fcptl)*/ 
        distinct fcptl.user_concurrent_program_name  "Program Name" 
 FROM   (SELECT /*+ index (fcr1 fnd_concurrent_requests_n3) */ fcr1.request_id 
         FROM   apps.fnd_concurrent_requests fcr1 
         WHERE  1 = 1 
         START WITH fcr1.request_id = &parent_request_id 
         CONNECT BY PRIOR fcr1.request_id = fcr1.parent_request_id) x, 
        apps.fnd_concurrent_requests fcr, 
        apps.fnd_concurrent_programs fcp, 
        apps.fnd_concurrent_programs_tl fcptl 
 WHERE  fcr.request_id = x.request_id 
        AND fcr.concurrent_program_id = fcp.concurrent_program_id 
        AND fcr.program_application_id = fcp.application_id 
        AND fcp.application_id = fcptl.application_id 
        AND fcp.concurrent_program_id = fcptl.concurrent_program_id 
        AND fcptl.LANGUAGE = 'US' 
 ORDER  BY 1;

