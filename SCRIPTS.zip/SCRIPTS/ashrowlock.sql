col EVENT form a60;

select        count(*) cnt, 
                 session_id sid,
                 substr(event,1,30) event, 
                 mod(p1,16)  as lm,
                 sql_id,
                 CURRENT_OBJ# || ' ' || object_name obj
               , o.object_type type
               , CURRENT_FILE# file#
               , CURRENT_BLOCK#  block#
               , blocking_session bsid
    from v$active_session_history ash,
         all_objects o
    where
            event  like 'enq: T%'
      and o.object_id (+)= ash.current_obj#
   group by event,session_id,p1,sql_ID,CURRENT_OBJ#,OBJECT_NAME,OBJECT_TYPE,CURRENT_FILE#, CURRENT_BLOCK#, BLOCKING_SESSION
   order by  count(*);


select    substr(event,1,30) event, sql_id,
             CURRENT_OBJ# || ' ' || object_name obj
           , o.object_type type
           , CURRENT_FILE# file#
           , CURRENT_BLOCK#  block#
    from v$active_session_history ash,
             ( select a.object_name, 
                      a.object_id,
                      decode(a.object_type,'INDEX',i.index_type||' '||'INDEX',a.object_type) object_type
               from all_objects a, all_indexes i where 
               a.owner=i.owner(+) and a.object_name=i.index_name(+) ) o
    where
            event  like 'enq: TX%'
      and o.object_id (+)= ash.current_obj#
    order by sample_time;
