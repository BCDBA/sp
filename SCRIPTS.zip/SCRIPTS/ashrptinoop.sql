Rem
Rem $Header: rdbms/admin/ashrptinoop.sql /main/1 2008/10/16 17:59:23 sburanaw Exp $
Rem
Rem ashrptinoop.sql
Rem
Rem Copyright (c) 2008, Oracle and/or its affiliates. All rights reserved.
Rem
Rem    NAME
Rem      ashrptinoop.sql - <one-line expansion of the name>
Rem
Rem    DESCRIPTION
Rem      <short description of component this file declares/defines>
Rem
Rem    NOTES
Rem      <other useful comments, qualifications, etc.>
Rem
Rem    MODIFIED   (MM/DD/YY)
Rem    akini       09/11/08 - ash report do nothing script
Rem    akini       09/11/08 - Created
Rem

