
-- set nls_timezone_tz_format to 'yyyy-mm-dd hh24:mi:ss tzh:tzm'
-- 26 char
@@tz_set

@@schedcols

set serveroutput on size 1000000
set linesize 200 trimspool on
set pagesize 60
