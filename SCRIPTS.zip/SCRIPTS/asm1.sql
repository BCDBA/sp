select name, total_mb/1024 TOTAL_GB, free_mb/1024 FREE_GB , (total_mb/1024) - (free_mb/1024) "used_Gb",
(free_mb/total_mb)*100 "FREE_PER" from v$asm_diskgroup;