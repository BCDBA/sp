select inst_id,trunc(completion_time),count(*) from 
gv$archived_log group by trunc(completion_time),inst_id order by 2,1;
