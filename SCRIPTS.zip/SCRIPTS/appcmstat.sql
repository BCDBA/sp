

set pages 9000
Set LineSize 9000
Column Manager  Heading 'Manager'  Format A65
Column Node     Heading 'Target'     Format A40
Column ApId     Heading 'Appl ID'  Format 9999990
Column Q_Id     Heading 'Q ID'     Format 9999990
Column Running  Heading 'Running'  Format 990
Column Max      Heading 'Max'      Format 999
Column Buf      Heading 'Buf'      Format 999

set head off
Select
'------------------------------------------------------------
  Managers with their defined capacities for the current shift
 ------------------------------------------------------------'
  from Dual;

set head on
select Application_Id ApId, concurrent_queue_id Q_Id,
       User_Concurrent_Queue_Name Manager,  Target_Node Node,
       Running_Processes Running,
       Max_Processes Max, Cache_Size Buf, Diagnostic_Level D
from APPS.fnd_concurrent_queues_vl
/



Column OsId       Format A10
Column CpId       Format 9999999990
Column Opid       Format 999
Column Manager    Format A65
Column Node       Format A40
Column Started_At Format A25

Column Q_Id       Format 99999990
Column Q_Id    Heading 'Q ID'

Column Cpid    Heading 'Cpid'
Column Node    Heading 'Node'
Column OsId       Heading 'System|Pid'
Column Opid       Heading 'Oracle|Pid'
Column Manager    Heading  Manager
Column Started_At Heading 'Started at'
Column Opid       Justify  Left
Column Instance   Heading 'Instance'
Column Instance   Format 99

set head off
Select
'      ----------------------------------------------------------------
       Managers with their corresponding Oracle and System Process Id''s
       ----------------------------------------------------------------'
from dual;

set head on
Select distinct Concurrent_Process_Id CpId,
       GVS.Inst_ID Instance,
       GVP.PID Opid,
       Os_Process_ID Osid,
       Q.User_Concurrent_Queue_Name Manager,
       P.Node_Name Node,
       To_Char(P.Process_Start_Date, 'MM-DD-YY HH:MI:SSAM') Started_At
  from  APPS.Fnd_Concurrent_Processes P, APPS.Fnd_Concurrent_Queues_Vl Q,
        GV$Process GVP, GV$Session GVS
 where  Q.Application_Id = Queue_Application_ID
   And (Q.Concurrent_Queue_ID = P.Concurrent_Queue_ID)
   And (GVS.Process = Os_Process_ID )
   And (GVP.ADDR = GVS.PADDR )
   And  Process_Status_Code not in ('K','S')
  Order by GVS.Inst_ID, P.Node_Name, Concurrent_Process_ID,
           Q.User_Concurrent_Queue_Name
;

set head off
Select
'      ----------------------------------------------------------------
                      Managers that are having problems
       ( Look into W<Cpid>.mgr under $FND_TOP/log for more information )'
from dual;

set head on
Select distinct Concurrent_Process_Id CpId,
       Oracle_Process_ID Opid,
       Os_Process_ID Osid,
       User_Concurrent_Queue_Name Manager,
       P.Node_Name Node,
       To_Char(P.Process_Start_Date, 'MM-DD-YY HH:MI:SSAM') Started_At
  from  APPS.Fnd_Concurrent_Processes P, APPS.Fnd_Concurrent_Queues_Vl Q
 where  Q.Application_Id = Queue_Application_ID
   And  Q.Concurrent_Queue_ID = P.Concurrent_Queue_ID
   And  P.Concurrent_Queue_ID <> 1
   And  (Os_Process_ID ) Not in
           ( Select GVS.Process
               from GV$SESSION GVS
              Where GVS.Process Is Not Null )
   And  ( Process_Status_Code = 'A' OR
          Process_Status_Code = 'R' OR
          Process_Status_Code = 'T' )
  Order by Os_Process_Id,
           Concurrent_Process_ID, Q.User_Concurrent_Queue_Name
;


set head off
Select
'      ----------------------------------------------------------------
                Managers that are not active at this instant
       ----------------------------------------------------------------'
from dual;

Column Application_Name Format A50
Column Application_Name Heading 'Application Name'
Column QId  Format 99999
Column Node Format A40
Column Manager Format A65

set head on
Select Application_Name, Concurrent_Queue_Id QId,
       User_Concurrent_Queue_Name Manager, Node_Name Node
  from APPS.Fnd_Concurrent_Queues_Vl Q, APPS.Fnd_Application_Vl A
 where  A.Application_Id = Q.Application_ID
   And  Max_Processes = 0
   And  Running_Processes = 0
   And  Q.Concurrent_Queue_ID <> 1
 order  by Application_Name, User_Concurrent_Queue_Name
;
