 SELECT Usr.User_Name,
 Usr.Description,
 XXARTO_GET_PWD.Decrypt (
 (SELECT (SELECT XXARTO_GET_PWD.Decrypt (
Fnd_Web_Sec.Get_Guest_Username_Pwd,
 Usertable.Encrypted_Foundation_Password)
 FROM DUAL)
AS Apps_Password
 FROM applsys.Fnd_User Usertable
 WHERE Usertable.User_Name =
 (SELECT SUBSTR (
 Fnd_Web_Sec.Get_Guest_Username_Pwd,
 1,
 INSTR (Fnd_Web_Sec.Get_Guest_Username_Pwd,
 '/')
 - 1)
 FROM DUAL)),
 Usr.Encrypted_User_Password)
 Password
 FROM applsys.Fnd_User Usr
 WHERE Usr.User_Name = '&User_Name';





