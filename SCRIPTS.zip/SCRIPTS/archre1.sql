col KBYTES form a40;
select c.inst_id,c.username,c.sid,c.serial#,c.process,to_char( b.value/1024,
'999,999,999' ) || ' kbytes' kbytes
from gv$statname a, gv$sesstat b, gv$session c
where a.statistic# = b.statistic#
and b.sid = c.sid
and a.name = 'redo size'
and c.username is not null
and b.value > 102400
group by c.inst_id,c.username,c.sid,c.serial#,c.process,to_char( b.value/1024,'999,999,999' ) || ' kbytes'
order by 6 desc ;