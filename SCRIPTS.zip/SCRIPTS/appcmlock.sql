
set head off
Select
'          ------------------------------
           Lock(s) that ICM is waiting on
           ------------------------------'
  from Dual;

set head on

select SH.OSUSER,
       SH.PROCESS,
       SH.MACHINE,
       SH.TERMINAL,
       SH.PROGRAM
  from V$SESSION SH
 where SH.SID in (select LH.SID
                  from V$LOCK LW,
                       V$LOCK LH,
                       V$SESSION SW,
                       APPS.FND_CONCURRENT_PROCESSES
                 where LH.SID <> SW.SID
                   and LH.ID1 = LW.ID1
                   and LH.ID2 = LW.ID2
                   and LW.KADDR = SW.LOCKWAIT
                   and SW.LOCKWAIT is not null
                   and SW.PROCESS = OS_PROCESS_ID
                   and QUEUE_APPLICATION_ID = 0
                   and CONCURRENT_QUEUE_ID = 1);
set head off
Select
'          ------------------------------
           Lock(s) that CRM is waiting on
           ------------------------------'
  from Dual;

set head on

select SH.OSUSER,
       SH.PROCESS,
       SH.MACHINE,
       SH.TERMINAL,
       SH.PROGRAM
  from V$SESSION SH,
       V$LOCK LW,
       V$LOCK LH,
       V$SESSION SW,
       APPS.FND_CONCURRENT_PROCESSES
 where LH.SID = SH.SID
   and LH.SID <> SW.SID
   and LH.ID1 = LW.ID1
   and LH.ID2 = LW.ID2
   and LW.KADDR = SW.LOCKWAIT
   and SW.LOCKWAIT is not null
   and SW.PROCESS = OS_PROCESS_ID
   and QUEUE_APPLICATION_ID = 0
   and CONCURRENT_QUEUE_ID = 4;
