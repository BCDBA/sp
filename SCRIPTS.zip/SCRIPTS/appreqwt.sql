
Set Pages 6000
Set Linesize 6000

Column Reqst     Format 9999999
Column Orcl      Format A8
Column Priority  Format 99999
Column Program   Format A10
Column Start_At  Format A15
Column Req_Date  Format A15

Column Reqst    HEADING 'Request|ID'
Column Orcl     HEADING 'Oracle|Name'
Column Priority HEADING 'Priority'
Column Program  HEADING 'Program'
Column Req_Date HEADING 'Requested at'
Column Start_At HEADING 'To Start at'

Break On Report
Comput Count OF Reqst ON Report

TTITLE 'Pending for Conflict Resolution Manager'

select request_id Reqst,  Oracle_Username Orcl, Priority,
       Concurrent_Program_Name Program,
       To_Char(Request_Date, 'MM-DD-YY HH24:MI') Req_Date,
       To_Char(Requested_Start_Date, 'MM-DD-YY HH24:MI') Start_At,
       Run_Alone_Flag, Single_Thread_Flag, Fcp.Enabled_Flag
from APPS.fnd_concurrent_requests Fcr, APPS.Fnd_Concurrent_Programs Fcp,
     APPS.fnd_oracle_userid O
where Status_Code = 'Q'
  And (
       Fcr.Concurrent_Program_Id = Fcp.Concurrent_Program_Id And
          Program_Application_ID = Application_ID )
  And  Hold_Flag = 'N'
  And  Fcr.Oracle_ID = O.Oracle_ID
  And  Requested_Start_Date <= Sysdate
Order By  Requested_Start_Date Asc,
          Decode(Priority, Null, 9999999, Priority) Asc,
          Request_ID Asc
/


TTITLE 'Pending for Conflict Resolution Manager|( requested to run at a later time )'

select request_id Reqst,  Oracle_Username Orcl, Priority,
       Concurrent_Program_Name Program,
       To_Char(Request_Date, 'MM-DD-YY HH24:MI') Req_Date,
       To_Char(Requested_Start_Date, 'MM-DD-YY HH24:MI') Start_At,
       Run_Alone_Flag, Single_Thread_Flag, Fcp.Enabled_Flag
from APPS.fnd_concurrent_requests Fcr, APPS.Fnd_Concurrent_Programs Fcp,
     APPS.fnd_oracle_userid O
where Status_Code = 'Q'
  And (
       Fcr.Concurrent_Program_Id = Fcp.Concurrent_Program_Id And
          Program_Application_ID = Application_ID )
  And  Hold_Flag = 'N'
  And  Fcr.Oracle_ID = O.Oracle_ID
  And  Requested_Start_Date > Sysdate
Order By  Requested_Start_Date Asc,
          Decode(Priority, Null, 9999999, Priority) Asc,
          Request_ID Asc
/


TTITLE 'Pending for Conflict Resolution Manager|( on Hold )'

select request_id Reqst,  Oracle_Username Orcl, Priority,
       Concurrent_Program_Name Program,
       To_Char(Request_Date, 'MM-DD-YY HH24:MI') Req_Date,
       To_Char(Requested_Start_Date, 'MM-DD-YY HH24:MI') Start_At,
       Run_Alone_Flag, Single_Thread_Flag, Fcp.Enabled_Flag
from APPS.fnd_concurrent_requests Fcr, APPS.Fnd_Concurrent_Programs Fcp,
     APPS.fnd_oracle_userid O
where Status_Code = 'Q'
  And (
       Fcr.Concurrent_Program_Id = Fcp.Concurrent_Program_Id And
          Program_Application_ID = Application_ID )
  And  Hold_Flag = 'Y'
  And  Fcr.Oracle_ID = O.Oracle_ID
Order By  Requested_Start_Date Asc,
          Decode(Priority, Null, 9999999, Priority) Asc,
          Request_ID Asc
/


TTITLE 'Waiting Concurrent Requests'

select request_id Reqst,  Oracle_Username Orcl, Priority,
       Concurrent_Program_Name Program,
       To_Char(Request_Date, 'MM-DD-YY HH24:MI') Req_Date,
       To_Char(Requested_Start_Date, 'MM-DD-YY HH24:MI') Start_At,
       Run_Alone_Flag, Single_Thread_Flag, Fcp.Enabled_Flag
from APPS.fnd_concurrent_requests Fcr, APPS.Fnd_Concurrent_Programs Fcp,
     APPS.fnd_oracle_userid O
where Status_Code = 'A'
  And (
       Fcr.Concurrent_Program_Id = Fcp.Concurrent_Program_Id And
          Program_Application_ID = Application_ID )
  And  Fcr.Oracle_ID = O.Oracle_ID
Order By  Requested_Start_Date Asc,
          Decode(Priority, Null, 9999999, Priority) Asc,
          Request_ID Asc
/


TTITLE OFF
Clear Breaks
Clear Computes
