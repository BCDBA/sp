select group_number,name, total_mb, free_mb, total_mb - free_mb "used_mb" from v$asm_diskgroup;

col PATH form a60;

select GROUP_NUMBER,DISK_NUMBER,MOUNT_STATUS,HEADER_STATUS,REDUNDANCY,NAME,PATH from v$asm_disk where group_number=&GROUP_NUMBER;