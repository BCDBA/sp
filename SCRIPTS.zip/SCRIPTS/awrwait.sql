column db_name         format a8  heading 'Database|Name'
column instance_number format 999 heading 'Instance|Number'
column host_name       format a12 heading 'Host Name'
column begin_interval_time format a20
column end_interval_time format a20
column wait_class format a20
column event_name format a20

SELECT * FROM (
SELECT	db_name, instance_number, host_name
,	snap_id
, 	begin_interval_time, end_interval_time, secs
,	wait_class, event_name
,	total_Waits - last_total_Waits as total_waits
,	total_timeouts - last_total_timeouts as total_timeouts
,	time_waited_micro - last_time_waited_micro as time_waited_micro
,	(time_waited_micro - last_time_waited_micro)/1000000 as time_waited
,	(time_waited_micro - last_time_waited_micro)/1000000/secs as time_waited_per_second
FROM	(
	SELECT	i.db_name, i.host_name
	,	s.dbid, s.instance_number, s.startup_time
        ,       MIN(s.begin_interval_time) OVER (partition by s.dbid, s.snap_id) AS begin_interval_time 
        ,       MIN(s.end_interval_time) OVER (partition by s.dbid, s.snap_id) AS end_interval_time 
	,	e.wait_class, e.event_name
--
	, 	s.snap_id
	,	LAG(s.snap_id) OVER (
			PARTITION BY s.dbid, s.instance_number, s.startup_time, e.event_name
			ORDER BY s.snap_id) AS last_snap_id
--
	,	e.total_waits
	,	LAG(e.total_waits) OVER (
			PARTITION BY s.dbid, s.instance_number, s.startup_time, e.event_name
			ORDER BY s.snap_id) AS last_total_waits
--
	,	e.total_timeouts
	,	LAG(e.total_timeouts) OVER (
			PARTITION BY s.dbid, s.instance_number, s.startup_time, e.event_name
			ORDER BY s.snap_id) AS last_total_timeouts
--
	,	e.time_waited_micro
	,	LAG(e.time_waited_micro) OVER (
			PARTITION BY s.dbid, s.instance_number, s.startup_time, e.event_name
			ORDER BY s.snap_id) AS last_time_waited_micro
--
	,	86400*(TO_NUMBER(TO_CHAR(end_interval_time,'J'))
	       -TO_NUMBER(TO_CHAR(begin_interval_time,'J')))
	+	3600*(EXTRACT(HOUR FROM end_interval_time)-EXTRACT(HOUR FROM begin_interval_time))
	+	60*(EXTRACT(MINUTE FROM end_interval_time)-EXTRACT(MINUTE FROM begin_interval_time))
	+	EXTRACT(SECOND FROM end_interval_time)-EXTRACT(SECOND FROM begin_interval_time) secs
	FROM	dba_hist_snapshot s
	INNER JOIN dba_hist_database_instance i
		ON i.dbid = s.dbid 
		AND i.instance_number = s.instance_number
		AND i.startup_time = s.startup_time	
	INNER JOIN dba_hist_system_event e --v$system_event
		ON e.snap_id = s.snap_id
		AND e.dbid = s.dbid
		AND e.instance_number = s.instance_number
	WHERE  s.begin_interval_time > TRUNC(SYSDATE) - 7
	) x
WHERE 	last_snap_id IS NOT NULL
AND	secs > 0
AND	( total_Waits > last_total_Waits
	OR total_timeouts > last_total_timeouts
	OR time_waited_micro > last_time_waited_micro))
ORDER BY 1,2,3,4
/