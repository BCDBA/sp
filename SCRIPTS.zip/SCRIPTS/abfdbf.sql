SELECT tablespace_name, file_id "AFN", relative_fno "RFN"
from dba_data_files order by file_id,relative_fno;
