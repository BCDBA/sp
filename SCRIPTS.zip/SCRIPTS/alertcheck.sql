set serveroutput on size 1000000
set lines 200 pages 0 feed off head off
break on grantee
exec dbms_output.enable(90000000);
alter session set nls_date_format='DD-MON-YYYY HH24:MI:SS';

DECLARE
   v_sid v$database.name%TYPE; /* database */
   v_bdumpdest v$parameter.value%TYPE; /* directory of alert.log */
   v_count NUMBER;
   v_alertname VARCHAR2( 19); /* name of the alert.log */
   v_file_handle utl_file.file_type; /* handle tp alert.log */
   v_eof BOOLEAN := FALSE;
   v_text VARCHAR2( 2000);
   v_date_try DATE; /* Help var. for date line in de alert.log */
   v_date DATE; /* Keep de date line from alert.log */
   v_date_is_new BOOLEAN; /* Datum to be displayed */
   v_interesting BOOLEAN := FALSE; /* Relevant content from the alert.log */
   c_aantal_uren NUMBER := &time_duration ; /* Total  Hrs. from the time the contents have to be displayed */
   errcnt number := 0;

   FUNCTION file_does_exist (location_in IN VARCHAR2, filename_in IN VARCHAR2)
   RETURN BOOLEAN AS
      v_file_handle utl_file.file_type;
   BEGIN
      v_file_handle := utl_file.fopen ( location => location_in, filename => filename_in, open_mode => 'R', MAX_LINESIZE=> 32767);
      utl_file.fclose( file => v_file_handle);
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         RETURN FALSE;
   END file_does_exist;

BEGIN

   SELECT instance_name INTO v_sid FROM v$instance;
   SELECT value INTO v_bdumpdest FROM v$parameter WHERE name = 'background_dump_dest';
   SELECT COUNT(*) INTO v_count FROM v$version WHERE banner LIKE '%Windows%';
   execute immediate 'create or replace directory bdump_dir as' || '''' || v_bdumpdest || '''';
   IF v_count = 0 THEN
      IF file_does_exist ( location_in => 'BDUMP_DIR' , filename_in => 'alert_' || v_sid || '.log')
      THEN
         v_alertname := 'alert_' || v_sid || '.log';
      ELSE
         v_alertname := 'alert_' || LOWER( v_sid) || '.log';
      END IF;
   ELSE
      /* Windows machine */
      v_alertname := 'alert_' || v_sid || '.log';
   END IF;

   BEGIN
      v_file_handle := utl_file.fopen ( location => 'BDUMP_DIR', filename => v_alertname, open_mode => 'R', MAX_LINESIZE=> 32767);
   EXCEPTION
      WHEN utl_file.invalid_mode THEN
         RAISE_APPLICATION_ERROR (-20001, 'the open_mode string was invalid');
   END;

   WHILE NOT v_eof
   LOOP
      BEGIN
         utl_file.get_line ( file => v_file_handle, buffer => v_text);
      EXCEPTION
         WHEN NO_DATA_FOUND THEN
            v_eof := TRUE;
         WHEN value_error THEN
            utl_file.fclose_all;
            RAISE_APPLICATION_ERROR
            ( -20001, 'line too long to store in buffer');
         WHEN utl_file.invalid_operation THEN
            utl_file.fclose_all;
            RAISE_APPLICATION_ERROR
            ( -20001, 'file is not open for reading');
         WHEN utl_file.read_error THEN
            utl_file.fclose_all;
            RAISE_APPLICATION_ERROR
            ( -20001, 'OS error occurred during read : ' || sqlerrm);
      END;

      IF v_interesting THEN
         IF (SUBSTR(v_text, 4, 1) = '-' or v_text like '%was suspended due to%') /* 'ORA-..., PLS-..., etc. */
         THEN
            IF v_date_is_new THEN
               dbms_output.put (CHR( 10));
               dbms_output.put_line
               ( INITCAP( TO_CHAR( v_date, 'DY MON DD HH24:MI:SS YYYY')));
            END IF;
            v_date_is_new := FALSE;
            dbms_output.put_line( SUBSTR( v_text, 1, 150));
            errcnt := errcnt + 1;
         END IF;
      END IF;

      BEGIN
         v_date_try := TO_DATE(replace(v_text,'IST '), 'DY MON DD HH24:MI:SS YYYY');
         IF v_date != v_date_try OR v_date IS NULL
         THEN
            v_date := v_date_try;
            v_date_is_new := TRUE;
            IF trunc(v_date) = trunc(SYSDATE-c_aantal_uren) THEN
               v_interesting := TRUE;
            END IF;
            if trunc(v_date) > trunc(SYSDATE-c_aantal_uren) THEN
               v_interesting := false;
            end if;
         ELSE
            v_date_is_new := FALSE;
         END IF;
      EXCEPTION
         WHEN OTHERS THEN
            NULL; /* There is no date. The file is read further. */
      END;
   END LOOP;

   utl_file.fclose( file => v_file_handle);
   IF (ERRCNT = 0) THEN
        DBMS_OUTPUT.PUT_LINE (CHR(10) || 'NO ERROR FOUND IN GIVEN INTERVAL' || chr(10));
   END IF;
   dbms_output.put_line (CHR(10) || 'TOTAL ERRORS FOUND : ' || errcnt);
   dbms_output.put_line ('START TIME - ' || to_char(trunc(SYSDATE-c_aantal_uren),'DD-MON-YYYY HH24:MI:SS'));
   dbms_output.put_line ('END   TIME - ' || to_char(trunc(SYSDATE-c_aantal_uren+1)-1/86400,'DD-MON-YYYY HH24:MI:SS'));
EXCEPTION
   WHEN utl_file.invalid_path THEN
      dbms_output.put_line
      ( 'alerts.sql: utl_file.invalid_path encountered. ' ||
        'Check utl_file_dir.'
      );
   WHEN utl_file.invalid_operation THEN
      IF v_bdumpdest LIKE '%$%'
      OR v_bdumpdest LIKE '%?%'
      OR v_bdumpdest LIKE '%\%%' ESCAPE '\'
      THEN
         dbms_output.put_line
         ( 'alerts.sql: Unable to read alert.log because ' ||
           'of background_dump_dest parameter ' ||
           v_bdumpdest || '.'
         );
      ELSE
         dbms_output.put_line
         ( 'alerts.sql: utl_file.invalid_operation encountered at this stage.' || sqlerrm);
      END IF;
END;
/


set lines 200 pages 50000 head on feed on
clear break;
