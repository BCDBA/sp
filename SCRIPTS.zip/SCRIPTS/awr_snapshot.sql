-- Create AWR snapshot
EXEC DBMS_WORKLOAD_REPOSITORY.create_snapshot;