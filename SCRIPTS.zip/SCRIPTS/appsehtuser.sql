set echo off
set linesize 5000
set pages 6000
set head on
set feedback on
col sid head "Sid" form 9999 trunc
col serial# form 99999 trunc head "Ser#"
col machine form a25 trunc head "Client|Machine"
col program form a15 trunc head "Client|Program"
col client form a50 trunc head "Info"
col client_identifier form a20 trunc head "IDENTIFIER"
col module form a60 trunc head "module"
col login form a11
col "last call"  form 9999999 trunc head "Last Call|In Secs"
col status form a6 trunc
select to_char(sample_time,'mm/dd/yyyy hh24:mi') dt,INSTANCE_NUMBER,SESSION_ID,SESSION_SERIAL#, sum(TIME_WAITED),event,SQL_ID,SQL_PLAN_HASH_VALUE,module,action,program,machine,user_id
from DBA_HIST_ACTIVE_SESS_HISTORY 
where CLIENT_ID='&FND_USER'
group by  to_char(sample_time,'mm/dd/yyyy hh24:mi') ,INSTANCE_NUMBER,SESSION_ID,SESSION_SERIAL#,event,SQL_ID,SQL_PLAN_HASH_VALUE,module,action,program,machine,user_id
order by 1 desc
/