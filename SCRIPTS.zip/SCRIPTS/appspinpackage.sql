select substr(owner, 1,20) owner,substr(name,1,40) name, substr(type,1,15) type, 
to_char(sharable_mem/1024,'9,999.9') "SPACE(K)",
loads,executions execs from v$db_object_cache where kept='NO' and 
type in ('PACKAGE','PACKAGE BODY','PROCEDURE','TRIGGER','TYPE BODY','FUNCTION','SEQUENCE','CURSOR','JAVA CLASS')
and loads > 1 and executions >1 and sharable_mem/1024 > 25
order by loads desc;

select substr(owner, 1,20) owner,substr(name,1,40) name, substr(type,1,15) type, 
to_char(sharable_mem/1024,'9,999.9') "SPACE(K)",
loads,executions execs from v$db_object_cache where kept='YES' and
type in ('PACKAGE','PACKAGE BODY','PROCEDURE','TRIGGER','TYPE BODY','FUNCTION','SEQUENCE','CURSOR','JAVA CLASS')
and owner not in ('SYS','SYSTEM')
order by owner,name;