select name, total_mb/1024 TOT_GB , free_mb/1024 free_GB , (total_mb - free_mb)/1024 used_GB from v$asm_diskgroup;



