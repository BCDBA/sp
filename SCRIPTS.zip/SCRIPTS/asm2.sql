select name, total_mb/(1024*1024) TOTAL_TB, free_mb/(1024*1024) FREE_TB , (total_mb/(1024*1024)) - (free_mb/(1024*1024)) "used_Tb",
(free_mb/total_mb)*100 "FREE_PER" from v$asm_diskgroup order by 5 desc;


