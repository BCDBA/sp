SET SERVEROUTPUT ON ARRAYSIZE 1
SET LINES 32767 PAGES 50000
SET HEAD OFF FEED OFF VERIFY OFF EMBEDDED OFF TERMOUT OFF TRIMOUT ON TRIMSPOOL ON ESCAPE '`'
COLUMN SPOOLFILE NEW_VALUE FILE
SET TERMOUT OFF

SELECT    UPPER (SYS_CONTEXT ('userenv', 'instance_name'))
       || '_'
       || TO_CHAR (SYSDATE, 'MON-YYYY')
       || '.html'
          SPOOLFILE
  FROM DUAL;

SET TERMOUT ON
PROMPT ENTER THE REPORT MONTH
ACCEPT REPORT_MONTH
SPOOL ESMR_ALL_DATA_COLLECTION_&FILE

DECLARE
   DBNAME         VARCHAR2 (30);
   DBID           NUMBER;
   REPORT_MONTH   CHAR (8) := UPPER ('&REPORT_MONTH');
   INST_COUNT     NUMBER;
   BSNAP          NUMBER;
   ESNAP          NUMBER;
   VERSION        VARCHAR2 (20);

   TYPE SQLARRAY IS TABLE OF VARCHAR2 (100);

   SQLID          SQLARRAY := SQLARRAY ();
   V_SQL_ID       VARCHAR2 (100);
   V_SQL_TEXT     CLOB;
   V_SQL_COUNT    NUMBER := 0;

   CURSOR TOPMONTHCPU
   IS
        SELECT TOPSQL.SQL_ID,
               TOPSQL.MODULE,
               TOPSQL.CPU_TIME,
               TOPSQL.IO_TIME,
               TOPSQL.ELAPSED_TIME,
               TOPSQL.EXEC_COUNT,
               TOPSQL.CPU_TIME_PER_EXEC
          FROM (  SELECT STAT.SQL_ID,
                         STAT.MODULE,
                         ROUND (SUM (STAT.CPU_TIME_DELTA / 1000000), 0) CPU_TIME,
                         ROUND (SUM (STAT.IOWAIT_DELTA / 1000000), 0) IO_TIME,
                         ROUND (SUM (STAT.ELAPSED_TIME_DELTA / 1000000), 0)
                            ELAPSED_TIME,
                         ROUND (SUM (STAT.EXECUTIONS_DELTA), 0) EXEC_COUNT,
                         ROUND (
                            (SUM (STAT.CPU_TIME_DELTA)
                             / DECODE (SUM (STAT.EXECUTIONS_DELTA),
                                       0, 1,
                                       SUM (STAT.EXECUTIONS_DELTA)))
                            / 1000000,
                            0)
                            CPU_TIME_PER_EXEC,
                         RANK ()
                         OVER (
                            ORDER BY
                               ROUND (SUM (STAT.CPU_TIME_DELTA / 1000000), 0) DESC NULLS LAST)
                            AS TOPORDER
                    FROM DBA_HIST_SQLSTAT STAT,
                         DBA_HIST_SNAPSHOT SNAP,
                         DBA_HIST_SQLTEXT TEXT
                   WHERE     STAT.SNAP_ID = SNAP.SNAP_ID
                         AND STAT.SQL_ID = TEXT.SQL_ID
                         AND STAT.INSTANCE_NUMBER = SNAP.INSTANCE_NUMBER
                         AND TEXT.COMMAND_TYPE IN (2, 3, 6, 7)
						 AND      STAT.MODULE NOT IN ('FNDGSCST','DBMS_SCHEDULER','MSRFWOR','XXAR_CUSTPURGE_CHILD_PROG','ISServerExec.exe')
                         AND SNAP.SNAP_ID BETWEEN BSNAP AND ESNAP
						 AND STAT.SQL_ID NOT IN 
		(
'1mr4u2r99v9vc',
'3tgrf37vg0dtn',
'9q9v6sjgzd86f',
'4xqk7ycw3ju54',
'ga1zur8a52w6x',
'5jdmq42jqdgqf',
'9cfnxfk4dtvzz',
'011ds3v7z3ru7',
'70t4d127wjxa6',
'5vnj039930gb8',
'dg30updm144kw',
'fzfv592xkct0v',
'abfqvz076fxws',
'3r2fms4z05w7x',
'3zg4tuzsx997h',
'a2r25zygtbskt',
'1hvzf0fh7x95h',
'gn1mqn6mbgv4f',
'a9g37jgws9ftn',
'3j6pm7fcrzw4k',
'2asxzyn95j6xv',
'4qpz3hu49mvfy',
'8rj80zub4ahgw',
'1rbwj74q1htr7',
'7uqf9w4nn83cx',
'0zt5hfgyw9gj3',
'0c6f2gghhtzsc',
'7vpnam8ufn1fh',
'8qjp8ps5a034t',
'd5zd314f790hu',
'4qz8bpus5uxr3',
'3pgmuy3qr2rum',
'9qcvq5bffk5cc',
'5pnwdu6ctjdk4',
'bs65sdwfx1y0q',
'b5kckahhw0gr9',
'cuzcbh2jggvp4',
'504y5ryrj6vwv',
'dp5gxkxq21bmj',
'cpxzsazm39h1a',
'afcyw05bp8pt6',
'fxx74b977cb1d',
'3h5s7xncqt5k2',
'g2yygm309cvp9',
'bn2j3f4hpb4xq',
'9gwhpa8878v7d',
'0srpctgnt5nzy',
'14x13rn9fpvhz',
'b8g3db93jj0r9',
'6uqjnv9apssw8',
'f1urg058dnu45',
'gxathht7qk6kh',
'0kub698mnkuxj',
'92r4m3xg9a1x6',
'8sc3qxhw3ab3g',
'3h5s7xncqt5k2',
'bxpcfrjnfa7mt',
'5q72y4fu27fd2',
'2xptch1b82kx5',
'4bdnxkc1g10zh',
'cb8wgvfbzywu8',
'fw844s2ra7qzf',
'5dq7cc38dkk4v',
'3x154vs3c7f25',
'c1f3fjfpwxxr9',
'0uvkyq94sfy3h',
'9xzmkdjdm20cw',
'g2vhn6htqkmda',
'ar6cma2qa0akz',
'2kbfd2sf3b0cn',
'gm6dsjuxd9tck',
'2mxzjhx0tafc6',
'gyf9zgz6xhr90',
'fxx74b977cb1d',
'cp4xy0yfhbrkf',
'dhaj4cvgx2amr',
'4yrm79gv3wzrd',
'2yafwh8fmq8v9',
'dgptavgpgv6s5',
'52uhfg6pzudg2',
'c3b2g1sqxqm8z',
'8k3jv940vs2zb',
'2b5n4vy7mfnc3',
'4mgb6zuh7b0f1',
'bkrp3nqchg8p9',
'dp5gxkxq21bmj',
'gyf9zgz6xhr90',
'fxx74b977cb1d',
'b5kckahhw0gr9',
'cpxzsazm39h1a',
'3pawy8xxvpjdh',
'fxx74b977cb1d',
'92r4m3xg9a1x6',
'2cg4wqum22bsu',
'avukvx6m4sk33',
'd6z1wcxy71876',
'fqpp41g76hkjr',
'0au2nsp1q9d28',
'6fjjg830qgg9m',
'durpj5px6hwq9',
'0hjuxghctaa23',
'4cdtmz7m91t5t',
'05y5f6tjcjsra',
'4cdtmz7m91t5t',
'00ybt04m8fqah',
'264t265mvy7ux',
'6ft21105r7t20', 
'6g6kcdqd7wp0x',
'd957jfchh7asy', 
'5jn2fnzfk5zq2'
)
                GROUP BY STAT.SQL_ID, STAT.MODULE) TOPSQL
         WHERE TOPORDER < 21
      ORDER BY TOPSQL.CPU_TIME DESC;

   CURSOR TOPMONTHELA
   IS
        SELECT TOPSQL.SQL_ID,
               TOPSQL.MODULE,
               TOPSQL.CPU_TIME,
               TOPSQL.IO_TIME,
               TOPSQL.ELAPSED_TIME,
               TOPSQL.EXEC_COUNT,
               TOPSQL.ELAPSED_TIME_PER_EXEC
          FROM (  SELECT STAT.SQL_ID,
                         STAT.MODULE,
                         ROUND (SUM (STAT.CPU_TIME_DELTA / 1000000), 0) CPU_TIME,
                         ROUND (SUM (STAT.IOWAIT_DELTA / 1000000), 0) IO_TIME,
                         ROUND (SUM (STAT.ELAPSED_TIME_DELTA / 1000000), 0)
                            ELAPSED_TIME,
                         ROUND (SUM (STAT.EXECUTIONS_DELTA), 0) EXEC_COUNT,
                         ROUND (
                            (SUM (STAT.ELAPSED_TIME_DELTA)
                             / DECODE (SUM (STAT.EXECUTIONS_DELTA),
                                       0, 1,
                                       SUM (STAT.EXECUTIONS_DELTA)))
                            / 1000000,
                            0)
                            ELAPSED_TIME_PER_EXEC,
                         RANK ()
                         OVER (
                            ORDER BY
                               ROUND (SUM (STAT.ELAPSED_TIME_DELTA / 1000000), 0) DESC NULLS LAST)
                            AS TOPORDER
                    FROM DBA_HIST_SQLSTAT STAT,
                         DBA_HIST_SNAPSHOT SNAP,
                         DBA_HIST_SQLTEXT TEXT
                   WHERE STAT.SNAP_ID = SNAP.SNAP_ID
                         AND STAT.SQL_ID = TEXT.SQL_ID
                         AND STAT.INSTANCE_NUMBER = SNAP.INSTANCE_NUMBER
                         AND TEXT.COMMAND_TYPE IN (2, 3, 6, 7)
						 AND      STAT.MODULE NOT IN ('FNDGSCST','DBMS_SCHEDULER','MSRFWOR','XXAR_CUSTPURGE_CHILD_PROG','ISServerExec.exe')
                         AND SNAP.SNAP_ID BETWEEN BSNAP AND ESNAP
						 AND STAT.SQL_ID NOT IN
(
'1mr4u2r99v9vc',
'3tgrf37vg0dtn',
'9q9v6sjgzd86f',
'4xqk7ycw3ju54',
'ga1zur8a52w6x',
'5jdmq42jqdgqf',
'9cfnxfk4dtvzz',
'011ds3v7z3ru7',
'70t4d127wjxa6',
'5vnj039930gb8',
'dg30updm144kw',
'fzfv592xkct0v',
'abfqvz076fxws',
'3r2fms4z05w7x',
'3zg4tuzsx997h',
'a2r25zygtbskt',
'1hvzf0fh7x95h',
'gn1mqn6mbgv4f',
'a9g37jgws9ftn',
'3j6pm7fcrzw4k',
'2asxzyn95j6xv',
'4qpz3hu49mvfy',
'8rj80zub4ahgw',
'1rbwj74q1htr7',
'7uqf9w4nn83cx',
'0zt5hfgyw9gj3',
'0c6f2gghhtzsc',
'7vpnam8ufn1fh',
'8qjp8ps5a034t',
'd5zd314f790hu',
'4qz8bpus5uxr3',
'3pgmuy3qr2rum',
'9qcvq5bffk5cc',
'5pnwdu6ctjdk4',
'bs65sdwfx1y0q',
'b5kckahhw0gr9',
'cuzcbh2jggvp4',
'504y5ryrj6vwv',
'dp5gxkxq21bmj',
'cpxzsazm39h1a',
'afcyw05bp8pt6',
'fxx74b977cb1d',
'3h5s7xncqt5k2',
'g2yygm309cvp9',
'bn2j3f4hpb4xq',
'9gwhpa8878v7d',
'0srpctgnt5nzy',
'14x13rn9fpvhz',
'b8g3db93jj0r9',
'6uqjnv9apssw8',
'f1urg058dnu45',
'gxathht7qk6kh',
'0kub698mnkuxj',
'92r4m3xg9a1x6',
'8sc3qxhw3ab3g',
'3h5s7xncqt5k2',
'bxpcfrjnfa7mt',
'5q72y4fu27fd2',
'2xptch1b82kx5',
'4bdnxkc1g10zh',
'cb8wgvfbzywu8',
'fw844s2ra7qzf',
'5dq7cc38dkk4v',
'3x154vs3c7f25',
'c1f3fjfpwxxr9',
'0uvkyq94sfy3h',
'9xzmkdjdm20cw',
'g2vhn6htqkmda',
'ar6cma2qa0akz',
'2kbfd2sf3b0cn',
'gm6dsjuxd9tck',
'2mxzjhx0tafc6',
'gyf9zgz6xhr90',
'gyf9zgz6xhr90',
'fxx74b977cb1d',
'cp4xy0yfhbrkf',
'dhaj4cvgx2amr',
'4yrm79gv3wzrd',
'2yafwh8fmq8v9',
'dgptavgpgv6s5',
'52uhfg6pzudg2',
'c3b2g1sqxqm8z',
'8k3jv940vs2zb',
'2b5n4vy7mfnc3',
'4mgb6zuh7b0f1',
'bkrp3nqchg8p9',
'dp5gxkxq21bmj',
'gyf9zgz6xhr90',
'fxx74b977cb1d',
'b5kckahhw0gr9',
'cpxzsazm39h1a',
'3pawy8xxvpjdh',
'fxx74b977cb1d',
'92r4m3xg9a1x6',
'2cg4wqum22bsu',
'avukvx6m4sk33',
'd6z1wcxy71876',
'fqpp41g76hkjr',
'0au2nsp1q9d28',
'6fjjg830qgg9m',
'durpj5px6hwq9',
'0hjuxghctaa23',
'4cdtmz7m91t5t',
'05y5f6tjcjsra',
'4cdtmz7m91t5t',
'00ybt04m8fqah',
'264t265mvy7ux',
'6ft21105r7t20', 
'6g6kcdqd7wp0x',
'd957jfchh7asy', 
'5jn2fnzfk5zq2'
)
                GROUP BY STAT.SQL_ID, STAT.MODULE) TOPSQL
         WHERE TOPORDER < 21
      ORDER BY TOPSQL.ELAPSED_TIME DESC;

   CURSOR TOPMONTHDISK
   IS
        SELECT TOPSQL.SQL_ID,
               TOPSQL.MODULE,
               TOPSQL.CPU_TIME,
               TOPSQL.IO_TIME,
               TOPSQL.ELAPSED_TIME,
               TOPSQL.EXEC_COUNT,
               TOPSQL.DISK_READS
          FROM (  SELECT STAT.SQL_ID,
                         STAT.MODULE,
                         ROUND (SUM (STAT.CPU_TIME_DELTA / 1000000), 0) CPU_TIME,
                         ROUND (SUM (STAT.IOWAIT_DELTA / 1000000), 0) IO_TIME,
                         ROUND (SUM (STAT.ELAPSED_TIME_DELTA / 1000000), 0)
                            ELAPSED_TIME,
                         ROUND (SUM (STAT.EXECUTIONS_DELTA), 0) EXEC_COUNT,
                         ROUND (SUM (STAT.disk_reads_delta), 0) DISK_READS,
                         RANK ()
                         OVER (
                            ORDER BY ROUND (SUM (STAT.disk_reads_delta), 0) DESC NULLS LAST)
                            AS TOPORDER
                    FROM DBA_HIST_SQLSTAT STAT,
                         DBA_HIST_SNAPSHOT SNAP,
                         DBA_HIST_SQLTEXT TEXT
                   WHERE STAT.SNAP_ID = SNAP.SNAP_ID
                         AND STAT.SQL_ID = TEXT.SQL_ID
                         AND STAT.INSTANCE_NUMBER = SNAP.INSTANCE_NUMBER
                         AND TEXT.COMMAND_TYPE IN (2, 3, 6, 7)
						 AND      STAT.MODULE NOT IN ('FNDGSCST','DBMS_SCHEDULER','MSRFWOR','XXAR_CUSTPURGE_CHILD_PROG','ISServerExec.exe')
                         AND SNAP.SNAP_ID BETWEEN BSNAP AND ESNAP
						  AND STAT.SQL_ID NOT IN
	(
'1mr4u2r99v9vc',
'3tgrf37vg0dtn',
'9q9v6sjgzd86f',
'4xqk7ycw3ju54',
'ga1zur8a52w6x',
'5jdmq42jqdgqf',
'9cfnxfk4dtvzz',
'011ds3v7z3ru7',
'70t4d127wjxa6',
'5vnj039930gb8',
'dg30updm144kw',
'fzfv592xkct0v',
'abfqvz076fxws',
'3r2fms4z05w7x',
'3zg4tuzsx997h',
'a2r25zygtbskt',
'1hvzf0fh7x95h',
'gn1mqn6mbgv4f',
'a9g37jgws9ftn',
'3j6pm7fcrzw4k',
'2asxzyn95j6xv',
'4qpz3hu49mvfy',
'8rj80zub4ahgw',
'1rbwj74q1htr7',
'7uqf9w4nn83cx',
'0zt5hfgyw9gj3',
'0c6f2gghhtzsc',
'7vpnam8ufn1fh',
'8qjp8ps5a034t',
'd5zd314f790hu',
'4qz8bpus5uxr3',
'3pgmuy3qr2rum',
'9qcvq5bffk5cc',
'5pnwdu6ctjdk4',
'bs65sdwfx1y0q',
'b5kckahhw0gr9',
'cuzcbh2jggvp4',
'504y5ryrj6vwv',
'dp5gxkxq21bmj',
'cpxzsazm39h1a',
'afcyw05bp8pt6',
'fxx74b977cb1d',
'3h5s7xncqt5k2',
'g2yygm309cvp9',
'bn2j3f4hpb4xq',
'9gwhpa8878v7d',
'0srpctgnt5nzy',
'14x13rn9fpvhz',
'b8g3db93jj0r9',
'6uqjnv9apssw8',
'f1urg058dnu45',
'gxathht7qk6kh',
'0kub698mnkuxj',
'92r4m3xg9a1x6',
'8sc3qxhw3ab3g',
'3h5s7xncqt5k2',
'bxpcfrjnfa7mt',
'5q72y4fu27fd2',
'2xptch1b82kx5',
'4bdnxkc1g10zh',
'cb8wgvfbzywu8',
'fw844s2ra7qzf',
'5dq7cc38dkk4v',
'3x154vs3c7f25',
'c1f3fjfpwxxr9',
'0uvkyq94sfy3h',
'9xzmkdjdm20cw',
'g2vhn6htqkmda',
'ar6cma2qa0akz',
'2kbfd2sf3b0cn',
'gm6dsjuxd9tck',
'2mxzjhx0tafc6',
'gyf9zgz6xhr90',
'gyf9zgz6xhr90',
'fxx74b977cb1d',
'cp4xy0yfhbrkf',
'dhaj4cvgx2amr',
'4yrm79gv3wzrd',
'2yafwh8fmq8v9',
'dgptavgpgv6s5',
'52uhfg6pzudg2',
'c3b2g1sqxqm8z',
'8k3jv940vs2zb',
'2b5n4vy7mfnc3',
'4mgb6zuh7b0f1',
'bkrp3nqchg8p9',
'dp5gxkxq21bmj',
'gyf9zgz6xhr90',
'fxx74b977cb1d',
'b5kckahhw0gr9',
'cpxzsazm39h1a',
'3pawy8xxvpjdh',
'fxx74b977cb1d',
'92r4m3xg9a1x6',
'2cg4wqum22bsu',
'avukvx6m4sk33',
'd6z1wcxy71876',
'fqpp41g76hkjr',
'0au2nsp1q9d28',
'6fjjg830qgg9m',
'durpj5px6hwq9',
'0hjuxghctaa23',
'4cdtmz7m91t5t',
'05y5f6tjcjsra',
'4cdtmz7m91t5t',
'00ybt04m8fqah',
'264t265mvy7ux',
'6ft21105r7t20', 
'6g6kcdqd7wp0x',
'd957jfchh7asy', 
'5jn2fnzfk5zq2'
)
                GROUP BY STAT.SQL_ID, STAT.MODULE) TOPSQL
         WHERE TOPORDER < 21
      ORDER BY TOPSQL.DISK_READS DESC;

   CURSOR TOPMONTHGETS
   IS
        SELECT TOPSQL.SQL_ID,
               TOPSQL.MODULE,
               TOPSQL.CPU_TIME,
               TOPSQL.IO_TIME,
               TOPSQL.ELAPSED_TIME,
               TOPSQL.EXEC_COUNT,
               TOPSQL.BUFFER_GETS
          FROM (  SELECT STAT.SQL_ID,
                         STAT.MODULE,
                         ROUND (SUM (STAT.CPU_TIME_DELTA / 1000000), 0) CPU_TIME,
                         ROUND (SUM (STAT.IOWAIT_DELTA / 1000000), 0) IO_TIME,
                         ROUND (SUM (STAT.ELAPSED_TIME_DELTA / 1000000), 0)
                            ELAPSED_TIME,
                         ROUND (SUM (STAT.EXECUTIONS_DELTA), 0) EXEC_COUNT,
                         ROUND (SUM (STAT.buffer_gets_delta), 0) BUFFER_GETS,
                         RANK ()
                         OVER (
                            ORDER BY ROUND (SUM (STAT.buffer_gets_delta), 0) DESC NULLS LAST)
                            AS TOPORDER
                    FROM DBA_HIST_SQLSTAT STAT,
                         DBA_HIST_SNAPSHOT SNAP,
                         DBA_HIST_SQLTEXT TEXT
                   WHERE STAT.SNAP_ID = SNAP.SNAP_ID
                         AND STAT.SQL_ID = TEXT.SQL_ID
                         AND STAT.INSTANCE_NUMBER = SNAP.INSTANCE_NUMBER
                         AND TEXT.COMMAND_TYPE IN (2, 3, 6, 7)
						 AND      STAT.MODULE NOT IN ('FNDGSCST','DBMS_SCHEDULER','MSRFWOR','XXAR_CUSTPURGE_CHILD_PROG','ISServerExec.exe')
                         AND SNAP.SNAP_ID BETWEEN BSNAP AND ESNAP
						 AND STAT.SQL_ID NOT IN
	(
'1mr4u2r99v9vc',
'3tgrf37vg0dtn',
'9q9v6sjgzd86f',
'4xqk7ycw3ju54',
'ga1zur8a52w6x',
'5jdmq42jqdgqf',
'9cfnxfk4dtvzz',
'011ds3v7z3ru7',
'70t4d127wjxa6',
'5vnj039930gb8',
'dg30updm144kw',
'fzfv592xkct0v',
'abfqvz076fxws',
'3r2fms4z05w7x',
'3zg4tuzsx997h',
'a2r25zygtbskt',
'1hvzf0fh7x95h',
'gn1mqn6mbgv4f',
'a9g37jgws9ftn',
'3j6pm7fcrzw4k',
'2asxzyn95j6xv',
'4qpz3hu49mvfy',
'8rj80zub4ahgw',
'1rbwj74q1htr7',
'7uqf9w4nn83cx',
'0zt5hfgyw9gj3',
'0c6f2gghhtzsc',
'7vpnam8ufn1fh',
'8qjp8ps5a034t',
'd5zd314f790hu',
'4qz8bpus5uxr3',
'3pgmuy3qr2rum',
'9qcvq5bffk5cc',
'5pnwdu6ctjdk4',
'bs65sdwfx1y0q',
'b5kckahhw0gr9',
'cuzcbh2jggvp4',
'504y5ryrj6vwv',
'dp5gxkxq21bmj',
'cpxzsazm39h1a',
'afcyw05bp8pt6',
'fxx74b977cb1d',
'3h5s7xncqt5k2',
'g2yygm309cvp9',
'bn2j3f4hpb4xq',
'9gwhpa8878v7d',
'0srpctgnt5nzy',
'14x13rn9fpvhz',
'b8g3db93jj0r9',
'6uqjnv9apssw8',
'f1urg058dnu45',
'gxathht7qk6kh',
'0kub698mnkuxj',
'92r4m3xg9a1x6',
'8sc3qxhw3ab3g',
'3h5s7xncqt5k2',
'bxpcfrjnfa7mt',
'5q72y4fu27fd2',
'2xptch1b82kx5',
'4bdnxkc1g10zh',
'cb8wgvfbzywu8',
'fw844s2ra7qzf',
'5dq7cc38dkk4v',
'3x154vs3c7f25',
'c1f3fjfpwxxr9',
'0uvkyq94sfy3h',
'9xzmkdjdm20cw',
'g2vhn6htqkmda',
'ar6cma2qa0akz',
'2kbfd2sf3b0cn',
'gm6dsjuxd9tck',
'2mxzjhx0tafc6',
'gyf9zgz6xhr90',
'gyf9zgz6xhr90',
'fxx74b977cb1d',
'cp4xy0yfhbrkf',
'dhaj4cvgx2amr',
'4yrm79gv3wzrd',
'2yafwh8fmq8v9',
'dgptavgpgv6s5',
'52uhfg6pzudg2',
'c3b2g1sqxqm8z',
'8k3jv940vs2zb',
'2b5n4vy7mfnc3',
'4mgb6zuh7b0f1',
'bkrp3nqchg8p9',
'dp5gxkxq21bmj',
'gyf9zgz6xhr90',
'fxx74b977cb1d',
'b5kckahhw0gr9',
'cpxzsazm39h1a',
'3pawy8xxvpjdh',
'fxx74b977cb1d',
'92r4m3xg9a1x6',
'2cg4wqum22bsu',
'avukvx6m4sk33',
'd6z1wcxy71876',
'fqpp41g76hkjr',
'0au2nsp1q9d28',
'6fjjg830qgg9m',
'durpj5px6hwq9',
'0hjuxghctaa23',
'4cdtmz7m91t5t',
'05y5f6tjcjsra',
'4cdtmz7m91t5t',
'00ybt04m8fqah',
'264t265mvy7ux',
'6ft21105r7t20', 
'6g6kcdqd7wp0x',
'd957jfchh7asy', 
'5jn2fnzfk5zq2'
)
                GROUP BY STAT.SQL_ID, STAT.MODULE) TOPSQL
         WHERE TOPORDER < 21
      ORDER BY TOPSQL.BUFFER_GETS DESC;

 

   CURSOR WAITCLASS
   IS
      SELECT WAITC.WC "WC", ROUND (WAITC.TW * 100 / TTW.TTIME) "PCT"
        FROM (  SELECT WC.WAIT_CLASS WC, SUM (WC.TIME_WAITED / 100) TW
                  FROM DBA_HIST_SERVICE_WAIT_CLASS WC, DBA_HIST_SNAPSHOT SNAP
                 WHERE     WC.SNAP_ID = SNAP.SNAP_ID
                       AND SNAP.SNAP_ID BETWEEN BSNAP AND ESNAP
                       AND WC.WAIT_CLASS != 'Idle'
              GROUP BY WC.WAIT_CLASS
              ORDER BY 2 DESC) WAITC,
             (SELECT SUM (WC1.TIME_WAITED / 100) TTIME
                FROM DBA_HIST_SERVICE_WAIT_CLASS WC1, DBA_HIST_SNAPSHOT SNAP1
               WHERE     WC1.SNAP_ID = SNAP1.SNAP_ID
                     AND SNAP1.SNAP_ID BETWEEN BSNAP AND ESNAP
                     AND WC1.WAIT_CLASS != 'Idle') TTW;

   CURSOR TS
   IS
      SELECT TS.TABLESPACE_NAME TS_NAME,
             ROUND (TS.SIZE_IN_GB, 2) SIZE_GB,
             ROUND (TS.SIZE_IN_GB * 100 / TOTTS.SIZE_IN_GB, 2) PCT
        FROM (  SELECT TABLESPACE_NAME,
                       SUM (BYTES / 1024 / 1024 / 1024) SIZE_IN_GB
                  FROM DBA_DATA_FILES
                 WHERE TABLESPACE_NAME NOT IN
                          (SELECT TABLESPACE_NAME
                             FROM DBA_TABLESPACES
                            WHERE CONTENTS IN ('UNDO', 'TEMPORARY'))
              GROUP BY TABLESPACE_NAME
              ORDER BY SUM (BYTES / 1024 / 1024 / 1024) DESC) TS,
             (SELECT SUM (BYTES / 1024 / 1024 / 1024) SIZE_IN_GB
                FROM DBA_DATA_FILES
               WHERE TABLESPACE_NAME NOT IN
                        (SELECT TABLESPACE_NAME
                           FROM DBA_TABLESPACES
                          WHERE CONTENTS IN ('UNDO', 'TEMPORARY'))) TOTTS
       WHERE ROWNUM < 11;

   CURSOR SEGSIZE
   IS
      SELECT                                                       /*+ RULE */
            OWNER,
             SEGMENT_NAME,
             SEGMENT_TYPE,
             SIZE_GB
        FROM (SELECT SEG.OWNER,
                     SEG.SEGMENT_TYPE,
                     ROUND (SEG.SIZE_IN_GB, 2) SIZE_GB,
                     CASE SEG.SEGMENT_TYPE
                        WHEN 'LOBSEGMENT'
                        THEN
                           (SELECT L.TABLE_NAME || '.' || L.COLUMN_NAME
                              FROM DBA_LOBS L
                             WHERE L.SEGMENT_NAME = SEG.SEGMENT_NAME)
                        WHEN 'LOB PARTITION'
                        THEN
                           (SELECT L.TABLE_NAME || '.' || L.COLUMN_NAME
                              FROM DBA_LOBS L
                             WHERE L.SEGMENT_NAME = SEG.SEGMENT_NAME)
                        ELSE
                           SEG.SEGMENT_NAME
                     END
                        SEGMENT_NAME
                FROM (  SELECT OWNER,
                               SEGMENT_NAME,
                               SEGMENT_TYPE,
                               SUM (BYTES / 1024 / 1024 / 1024) SIZE_IN_GB
                          FROM DBA_SEGMENTS
                         WHERE SEGMENT_TYPE NOT IN ('TYPE2 UNDO')
                      GROUP BY OWNER, SEGMENT_NAME, SEGMENT_TYPE
                      ORDER BY SUM (BYTES / 1024 / 1024 / 1024) DESC) SEG
               WHERE ROWNUM < 21);
BEGIN
   SELECT NAME, DBID
     INTO DBNAME, DBID
     FROM V$DATABASE;

   SELECT COUNT (1) INTO INST_COUNT FROM GV$INSTANCE;

   SELECT PROPERTY_VALUE
     INTO VERSION
     FROM DATABASE_PROPERTIES
    WHERE PROPERTY_NAME = 'NLS_RDBMS_VERSION';

   SELECT MIN (SNAP_ID)
     INTO BSNAP
     FROM DBA_HIST_SNAPSHOT
    WHERE TO_CHAR (BEGIN_INTERVAL_TIME, 'MON-YYYY') = '&REPORT_MONTH';

   SELECT MAX (SNAP_ID)
     INTO ESNAP
     FROM DBA_HIST_SNAPSHOT
    WHERE TO_CHAR (BEGIN_INTERVAL_TIME, 'MON-YYYY') = '&REPORT_MONTH';

   DBMS_OUTPUT.
    PUT_LINE (
      '<STYLE type=''text/css''> TABLE { FONT-FAMILY: VERDANA,ARIAL,SANS-SERIF; FONT-SIZE:11PX; TEXT-ALIGN:AUTO; WIDTH:AUTO; ALIGN:LEFT; } TABLE TH { BACKGROUND-COLOR:#D4E3E5; } </STYLE>');
   DBMS_OUTPUT.
    PUT_LINE (
         '<H2 ALIGN=CENTER><B><U>ESMR Data Collection for &REPORT_MONTH - '
      || DBNAME
      || '</U></B></H2><BR>');
   DBMS_OUTPUT.
    PUT_LINE (
         '<TABLE><TR><TD>Begin Snap Id </TD><TD>'
      || BSNAP
      || '</TD><TD>End Snap Id </TD><TD>'
      || ESNAP
      || '</TD></TR></TABLE>');

   DBMS_OUTPUT.PUT_LINE ('<H4 ALIGN=LEFT>Top SQL by Total CPU Time</H4>');


   DBMS_OUTPUT.PUT_LINE ('<TABLE BORDER=1>');
   DBMS_OUTPUT.
    PUT_LINE (
      '<TR><TH>SQL ID</TH><TH>Module</TH><TH>CPU(Sec)</TH><TH>IO(Sec)</TH><TH>Elapsed(Sec)</TH>');
   DBMS_OUTPUT.PUT_LINE ('<TH>Exec. Count</TH><TH>CPU(Sec)/Exec</TH><TR>');

   FOR TOPMONTHCPUSQL IN TOPMONTHCPU
   LOOP
      SQLID.EXTEND;
      V_SQL_COUNT := V_SQL_COUNT + 1;
      SQLID (V_SQL_COUNT) := TOPMONTHCPUSQL.SQL_ID;
      DBMS_OUTPUT.
       PUT_LINE (
            '<TR><TD>'
         || REPLACE (TOPMONTHCPUSQL.SQL_ID, '<', '`&lt;')
         || '</TD>');
      DBMS_OUTPUT.
       PUT_LINE (
         '<TD>' || REPLACE (TOPMONTHCPUSQL.MODULE, '<', '`&lt;') || '</TD>');
      DBMS_OUTPUT.
       PUT_LINE (
         '<TD>' || REPLACE (TOPMONTHCPUSQL.CPU_TIME, '<', '`&lt;') || '</TD>');
      DBMS_OUTPUT.
       PUT_LINE (
         '<TD>' || REPLACE (TOPMONTHCPUSQL.IO_TIME, '<', '`&lt;') || '</TD>');
      DBMS_OUTPUT.
       PUT_LINE (
            '<TD>'
         || REPLACE (TOPMONTHCPUSQL.ELAPSED_TIME, '<', '`&lt;')
         || '</TD>');
      DBMS_OUTPUT.
       PUT_LINE (
            '<TD>'
         || REPLACE (TOPMONTHCPUSQL.EXEC_COUNT, '<', '`&lt;')
         || '</TD>');
      DBMS_OUTPUT.
       PUT_LINE (
            '<TD>'
         || REPLACE (TOPMONTHCPUSQL.CPU_TIME_PER_EXEC, '<', '`&lt;')
         || '</TD></TR>');
   END LOOP;

   DBMS_OUTPUT.PUT_LINE ('</TABLE>');

   DBMS_OUTPUT.PUT_LINE ('<H4 ALIGN=LEFT>Top SQL by Total Elapsed Time</H4>');


   DBMS_OUTPUT.PUT_LINE ('<TABLE BORDER=1>');
   DBMS_OUTPUT.
    PUT_LINE (
      '<TR><TH>SQL ID</TH><TH>Module</TH><TH>CPU(Sec)</TH><TH>IO(Sec)</TH><TH>Elapsed(Sec)</TH>');
   DBMS_OUTPUT.
    PUT_LINE ('<TH>Exec. Count</TH><TH>Elapsed(Sec)/Exec</TH><TR>');

   FOR TOPMONTHELASQL IN TOPMONTHELA
   LOOP
      SQLID.EXTEND;
      V_SQL_COUNT := V_SQL_COUNT + 1;
      SQLID (V_SQL_COUNT) := TOPMONTHELASQL.SQL_ID;
      DBMS_OUTPUT.
       PUT_LINE (
            '<TR><TD>'
         || REPLACE (TOPMONTHELASQL.SQL_ID, '<', '`&lt;')
         || '</TD>');
      DBMS_OUTPUT.
       PUT_LINE (
         '<TD>' || REPLACE (TOPMONTHELASQL.MODULE, '<', '`&lt;') || '</TD>');
      DBMS_OUTPUT.
       PUT_LINE (
         '<TD>' || REPLACE (TOPMONTHELASQL.CPU_TIME, '<', '`&lt;') || '</TD>');
      DBMS_OUTPUT.
       PUT_LINE (
         '<TD>' || REPLACE (TOPMONTHELASQL.IO_TIME, '<', '`&lt;') || '</TD>');
      DBMS_OUTPUT.
       PUT_LINE (
            '<TD>'
         || REPLACE (TOPMONTHELASQL.ELAPSED_TIME, '<', '`&lt;')
         || '</TD>');
      DBMS_OUTPUT.
       PUT_LINE (
            '<TD>'
         || REPLACE (TOPMONTHELASQL.EXEC_COUNT, '<', '`&lt;')
         || '</TD>');
      DBMS_OUTPUT.
       PUT_LINE (
            '<TD>'
         || REPLACE (TOPMONTHELASQL.ELAPSED_TIME_PER_EXEC, '<', '`&lt;')
         || '</TD></TR>');
   END LOOP;

   DBMS_OUTPUT.PUT_LINE ('</TABLE>');

   DBMS_OUTPUT.PUT_LINE ('<H4 ALIGN=LEFT>Top SQL by Total Disk Reads</H4>');


   DBMS_OUTPUT.PUT_LINE ('<TABLE BORDER=1>');
   DBMS_OUTPUT.
    PUT_LINE (
      '<TR><TH>SQL ID</TH><TH>Module</TH><TH>CPU(Sec)</TH><TH>IO(Sec)</TH><TH>Elapsed(Sec)</TH>');
   DBMS_OUTPUT.
    PUT_LINE (
      '<TH>Exec. Count</TH><TH>Disk Reads</TH><TR>');

   FOR TOPMONTHDISKSQL IN TOPMONTHDISK
   LOOP
      SQLID.EXTEND;
      V_SQL_COUNT := V_SQL_COUNT + 1;
      SQLID (V_SQL_COUNT) := TOPMONTHDISKSQL.SQL_ID;
      DBMS_OUTPUT.
       PUT_LINE (
            '<TR><TD>'
         || REPLACE (TOPMONTHDISKSQL.SQL_ID, '<', '`&lt;')
         || '</TD>');
      DBMS_OUTPUT.
       PUT_LINE (
         '<TD>' || REPLACE (TOPMONTHDISKSQL.MODULE, '<', '`&lt;') || '</TD>');
      DBMS_OUTPUT.
       PUT_LINE (
            '<TD>'
         || REPLACE (TOPMONTHDISKSQL.CPU_TIME, '<', '`&lt;')
         || '</TD>');
      DBMS_OUTPUT.
       PUT_LINE (
         '<TD>' || REPLACE (TOPMONTHDISKSQL.IO_TIME, '<', '`&lt;') || '</TD>');
      DBMS_OUTPUT.
       PUT_LINE (
            '<TD>'
         || REPLACE (TOPMONTHDISKSQL.ELAPSED_TIME, '<', '`&lt;')
         || '</TD>');
      DBMS_OUTPUT.
       PUT_LINE (
            '<TD>'
         || REPLACE (TOPMONTHDISKSQL.EXEC_COUNT, '<', '`&lt;')
         || '</TD>');
      DBMS_OUTPUT.
       PUT_LINE (
            '<TD>'
         || REPLACE (TOPMONTHDISKSQL.DISK_READS, '<', '`&lt;')
         || '</TD>');
   END LOOP;

   DBMS_OUTPUT.PUT_LINE ('</TABLE>');

   DBMS_OUTPUT.PUT_LINE ('<H4 ALIGN=LEFT>Top SQL by Total Buffer Gets</H4>');


   DBMS_OUTPUT.PUT_LINE ('<TABLE BORDER=1>');
   DBMS_OUTPUT.
    PUT_LINE (
      '<TR><TH>SQL ID</TH><TH>Module</TH><TH>CPU(Sec)</TH><TH>IO(Sec)</TH><TH>Elapsed(Sec)</TH>');
   DBMS_OUTPUT.
    PUT_LINE (
      '<TH>Exec. Count</TH><TH>Buffer Gets</TH><TR>');

   FOR TOPMONTHGETSSQL IN TOPMONTHGETS
   LOOP
      SQLID.EXTEND;
      V_SQL_COUNT := V_SQL_COUNT + 1;
      SQLID (V_SQL_COUNT) := TOPMONTHGETSSQL.SQL_ID;
      DBMS_OUTPUT.
       PUT_LINE (
            '<TR><TD>'
         || REPLACE (TOPMONTHGETSSQL.SQL_ID, '<', '`&lt;')
         || '</TD>');
      DBMS_OUTPUT.
       PUT_LINE (
         '<TD>' || REPLACE (TOPMONTHGETSSQL.MODULE, '<', '`&lt;') || '</TD>');
      DBMS_OUTPUT.
       PUT_LINE (
            '<TD>'
         || REPLACE (TOPMONTHGETSSQL.CPU_TIME, '<', '`&lt;')
         || '</TD>');
      DBMS_OUTPUT.
       PUT_LINE (
         '<TD>' || REPLACE (TOPMONTHGETSSQL.IO_TIME, '<', '`&lt;') || '</TD>');
      DBMS_OUTPUT.
       PUT_LINE (
            '<TD>'
         || REPLACE (TOPMONTHGETSSQL.ELAPSED_TIME, '<', '`&lt;')
         || '</TD>');
      DBMS_OUTPUT.
       PUT_LINE (
            '<TD>'
         || REPLACE (TOPMONTHGETSSQL.EXEC_COUNT, '<', '`&lt;')
         || '</TD>');
      DBMS_OUTPUT.
       PUT_LINE (
            '<TD>'
         || REPLACE (TOPMONTHGETSSQL.BUFFER_GETS, '<', '`&lt;')
         || '</TD></TR>');
   END LOOP;

   DBMS_OUTPUT.PUT_LINE ('</TABLE>');


   DBMS_OUTPUT.PUT_LINE ('<H4 ALIGN=LEFT>Wait Class Classification</H4>');
   DBMS_OUTPUT.PUT_LINE ('<TABLE BORDER=1>');
   DBMS_OUTPUT.PUT_LINE ('<TR><TH>Wait Class</TH><TH>%</TH></TR>');

   FOR WAITCLASSSQL IN WAITCLASS
   LOOP
      DBMS_OUTPUT.
       PUT_LINE (
         '<TR><TD>' || REPLACE (WAITCLASSSQL.WC, '<', '`&lt;') || '</TD>');
      DBMS_OUTPUT.
       PUT_LINE (
         '<TD>' || REPLACE (WAITCLASSSQL.PCT, '<', '`&lt;') || '</TD></TR>');
   END LOOP;

   DBMS_OUTPUT.PUT_LINE ('</TABLE>');

   DBMS_OUTPUT.PUT_LINE ('<H4 ALIGN=LEFT>TOP 10 Tablespace By Size</H4>');
   DBMS_OUTPUT.PUT_LINE ('<TABLE BORDER=1>');
   DBMS_OUTPUT.
    PUT_LINE ('<TR><TH>Tablespace Name</TH><TH>Size(GB)</TH><TH>%</TH></TR>');

   FOR TSSQL IN TS
   LOOP
      DBMS_OUTPUT.
       PUT_LINE (
         '<TR><TD>' || REPLACE (TSSQL.TS_NAME, '<', '`&lt;') || '</TD>');
      DBMS_OUTPUT.
       PUT_LINE ('<TD>' || REPLACE (TSSQL.SIZE_GB, '<', '`&lt;') || '</TD>');
      DBMS_OUTPUT.
       PUT_LINE ('<TD>' || REPLACE (TSSQL.PCT, '<', '`&lt;') || '</TD></TR>');
   END LOOP;

   DBMS_OUTPUT.PUT_LINE ('</TABLE>');

   DBMS_OUTPUT.PUT_LINE ('<H4 ALIGN=LEFT>TOP 20 Segments By Size</H4>');
   DBMS_OUTPUT.PUT_LINE ('<TABLE BORDER=1>');
   DBMS_OUTPUT.
    PUT_LINE (
      '<TR><TH>Owner</TH><TH>Segment Name</TH><TH>Segment Type</TH><TH>Size(GB)</TH></TR>');

   FOR SEGSIZESQL IN SEGSIZE
   LOOP
      DBMS_OUTPUT.
       PUT_LINE (
         '<TR><TD>' || REPLACE (SEGSIZESQL.OWNER, '<', '`&lt;') || '</TD>');
      DBMS_OUTPUT.
       PUT_LINE (
         '<TD>' || REPLACE (SEGSIZESQL.SEGMENT_NAME, '<', '`&lt;') || '</TD>');
      DBMS_OUTPUT.
       PUT_LINE (
         '<TD>' || REPLACE (SEGSIZESQL.SEGMENT_TYPE, '<', '`&lt;') || '</TD>');
      DBMS_OUTPUT.
       PUT_LINE (
         '<TD>' || REPLACE (SEGSIZESQL.SIZE_GB, '<', '`&lt;') || '</TD></TR>');
   END LOOP;

   DBMS_OUTPUT.PUT_LINE ('</TABLE>');

   DBMS_OUTPUT.PUT_LINE ('<H4 ALIGN=LEFT>SQL Text for All SQL</H4>');
   DBMS_OUTPUT.PUT_LINE ('<TABLE BORDER=1>');
   DBMS_OUTPUT.PUT_LINE ('<TR><TH>SQL ID </TH><TH>Text</TH></TR>');

   FOR I IN SQLID.FIRST .. SQLID.LAST
   LOOP
      SELECT SQL_ID, SQL_TEXT
        INTO V_SQL_ID, V_SQL_TEXT
        FROM DBA_HIST_SQLTEXT
       WHERE SQL_ID IN (SQLID (I));

      DBMS_OUTPUT.PUT_LINE ('<TR><TD>' || V_SQL_ID || '</TD>');
      DBMS_OUTPUT.
       PUT_LINE (
            '<TD>'
         || DBMS_LOB.SUBSTR (V_SQL_TEXT, DBMS_LOB.GETLENGTH (V_SQL_TEXT))
         || '</TD></TR>');
   END LOOP;

   DBMS_OUTPUT.PUT_LINE ('</TABLE>');
END;
/

SPOOL OFF