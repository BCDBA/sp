

select user_ID,USER_NAME from APPS.fnd_user where user_name ='&FND_USER';



SELECT val.level_id, val.level_value, val.profile_option_id,
val.profile_option_value
FROM apps.fnd_profile_options opt, apps.fnd_profile_option_values val
WHERE opt.profile_option_name = 'FND_INIT_SQL' AND
opt.profile_option_id = val.profile_option_id
;




--- ON DEBUG
---DECLARE
 --  stat   BOOLEAN;
---BEGIN 

  --- fnd_profile.INITIALIZE;
 ---  stat := fnd_profile.SAVE ('FND_INIT_SQL', 'BEGIN FND_CTL.FND_SESS_CTL ('','',''TRUE'',''TRUE'',''LOG'',''ALTER SESSION SET EVENTS=''''10046 TRACE NAME CONTEXT FOREVER, LEVEL 8''''''); END;', 'USER',7771);  
  --- COMMIT;
--END;



--- Disable
--DECLARE
 ---  stat   BOOLEAN;
---BEGIN 
 
 ---  fnd_profile.INITIALIZE;
 ---  stat := fnd_profile.SAVE ('FND_INIT_SQL', '', 'USER',7771);
--COMMIT;
---END;


