
select 'exec fnd_stats.verify_stats('&owner','&object_name');'  from dba_tables;

select 'exec fnd_stats.GATHER_TABLE_STATS( OWNNAME => '&owner', TABNAME=> '&tablename', PERCENT => 40, DEGREE => 4 );'  from dba_tables;

