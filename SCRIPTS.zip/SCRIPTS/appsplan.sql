select * from TABLE(dbms_xplan.display('APPS.AA_PLAN_TABLE',NULL,NULL));

----explain plan into APPS.AA_PLAN_TABLE for select * from dual;