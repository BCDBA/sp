

col sid head "Sid" form 999999 trunc
col serial# form 99999 trunc head "Ser#"
col username form a15 trunc
col osuser form a15 trunc
col machine form a20 trunc head "Client|Machine"
col program form a15 trunc head "Client|Program"
col APP_USER form a25
col login form a11
col "last call"  form 9999999 trunc head "Last Call|In Secs"
col status form a6 trunc
select inst_id,sid,serial#,substr(username,1,10) username,substr(osuser,1,10) osuser,
	 substr(program||module,1,15) program,substr(machine,1,22) machine,
	 to_char(logon_time,'ddMon hh24:mi') login,
	 last_call_et "last call",status,client_identifier APP_USER,module
from gv$session where client_identifier is not null  and status='ACTIVE' and  client_identifier not in('SYSADMIN')
order by login
/




COLUMN username FORMAT A13
COLUMN OSUSER FORMAT A13
COLUMN event FORMAT A36
COLUMN wait_class FORMAT A13
COLUMN STATE FORMAT A17

SELECT s.inst_id,
       NVL(s.username, '(oracle)') AS username,S.OSUSER,
       s.sid,
       s.serial#,
       s.ROW_WAIT_OBJ#,
       sw.event,
       sw.wait_class,
       sw.wait_time,
       sw.seconds_in_wait,
       sw.state,
       s.SQL_HASH_VALUE,
       s.sql_id,
s.prev_sql_id
FROM   gv$session_wait sw,
       gv$session s
WHERE  s.sid     = sw.sid
AND    s.inst_id = sw.inst_id
AND  sw.wait_class != 'Idle' and client_identifier is not null  and status='ACTIVE' and  client_identifier not in('SYSADMIN')
ORDER BY s.inst_id,sw.event,sw.seconds_in_wait DESC;
