col sid head "Sid" form 9999 trunc
col module for a40 trunc
col action for a20 trunc noprint
col uname for a10 trunc
col event for a30 trunc

select request_id,s.sid sid,s.serial# serial,to_char(logon_time,'dd/mm hh24:mi') dt,s.module module,s.action action,user_name uname,s.event,s.sql_id sql_id
from  gv$session s,gv$process p,apps.fnd_concurrent_requests fnd,apps.fnd_user fndu
where p.inst_id = s.inst_id
and p.addr = s.paddr 
and p.spid = fnd.oracle_process_id 
and  fnd.requested_by = fndu.user_id 
and	 fnd.status_code = 'R'
and	 fnd.phase_code = 'R'
and  request_id ='&request_id' 
order by 1
;



col PROCESS form a10;
select a.inst_id,a.sid,a.serial#, b.spid ,c.os_process_id ,a.process
from gv$session a, gv$process b,apps.fnd_concurrent_requests c where a.paddr = b.addr and request_id ='&request_id' 
and a.inst_id = b.inst_id and c.os_process_id = a.process;