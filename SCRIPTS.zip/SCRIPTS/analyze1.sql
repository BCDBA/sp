col table_name format a20
col owner format a10
col tablespace_name format a20
col last_analyzed format a15
select table_name,owner,tablespace_name,LAST_ANALYZED from dba_tables where owner='&owner';