BEGIN
Insert into asap.ppm_valid_circles
   (CIRCLE_ABBR, ORGANIZATION_ID, PPM_VALID)
 Values
   ('JK', '702', 'Y');
Insert into asap.ppm_valid_circles
   (CIRCLE_ABBR, ORGANIZATION_ID, PPM_VALID)
 Values
   ('AS', '701', 'Y');
Insert into asap.ppm_valid_circles
   (CIRCLE_ABBR, ORGANIZATION_ID, PPM_VALID)
 Values
   ('NE', '703', 'Y');
COMMIT;
END;
