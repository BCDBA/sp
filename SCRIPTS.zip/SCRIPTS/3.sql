select 'alter index '||owner||'.'||index_name||' rebuild tablespace NEW_INDEX parallel 6; 
alter index '||owner||'.'||index_name||' noparallel ;'
from dba_indexes  where status='UNUSABLE'  and table_name in (select segment_name from dba_segments where bytes/1024/1024/1024 <1) 
/