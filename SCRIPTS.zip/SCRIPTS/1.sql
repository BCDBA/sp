
create user tcs178869 identified by praveen#8869;
alter user  tcs178869 DEFAULT TABLESPACE USERS ;
alter user  tcs178869 TEMPORARY TABLESPACE TEMP;
grant create session to tcs178869;

grant dba to  tcs178869 ;

alter user  tcs178869 profile DBA_SEC;

select USERNAME,USER_ID,ACCOUNT_STATUS from dba_users  where USERNAME='TCS178869';


