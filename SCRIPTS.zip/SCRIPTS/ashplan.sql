SELECT
    ash.sql_plan_line_id,
    ash.sql_plan_operation,
    ash.sql_plan_options,
    p.object_name,
    round(
        100 * COUNT(*) / SUM(COUNT(1) ) OVER(),
        2
    ) "% time"
FROM
    v$active_session_history ash,
    v$sql_plan p
WHERE
        ash.sql_id = p.sql_id
    AND
        ash.sql_plan_hash_value = p.plan_hash_value
    AND
        ash.sql_plan_line_id = P.id
    AND
        ash.sql_id ='&sql_id'
    AND
        ash.sql_plan_hash_value =&plan_hash_value
GROUP BY
    ASH.SQL_PLAN_LINE_ID,
    ASH.SQL_PLAN_OPERATION,
    ASH.SQL_PLAN_OPTIONS,
    p.object_name
ORDER BY COUNT(*) DESC
/