

select 'exec  apps.fnd_stats.GATHER_TABLE_STATS(ownname=>'''||owner||''',tabname=>'''||table_name||''',percent=>40,DEGREE =>8);' 
from dba_tables where
table_name like '%&TABLE_NAME%' and owner= '&OWNER';


