set feed off;
set timi off;

set head off;
select ' ------DEF TS AS SYS------' from dual;
select 'POINT #1	: LIST OF USERS WITH DEFAULT TABLESPACE AS SYSTEM AND SYSAUX' from dual;
select 'RULE 		: NO USER SHOULD BE IN SYS TABLESPACE OTHER THAN SYS AND SYSTEM' from dual;
select 'RESOULITION	:MOVE THE USERS TO OTHER TABLESPACES LEAVING SYS AND SYSTEM USERS' from dual;
set head on;
select USERNAME,ACCOUNT_STATUS,LOCK_DATE,EXPIRY_DATE,DEFAULT_TABLESPACE,CREATED from dba_users where DEFAULT_TABLESPACE like 'SYS%';

set head off;
select ' --USERS WITH PROFILE DEF--' from dual;
select 'POINT #2	: LIST OF USERS WITH DEFAULT PROFILE' from dual;
select 'RULE 		: NO USER SHOULD BE IN DEFAULT PROFILE OTHER THAN SYS AND SYSTEM' from dual;
select 'RESOULITION	: MOVE THE USERS TO OTHER PROFILES AFTER DISCUSSING WITH APPLICATION TEAMS LEAVING SYS AND SYSTEM USERS' from dual;
set head on;
select USERNAME, ACCOUNT_STATUS,LOCK_DATE,EXPIRY_DATE,PROFILE from dba_users where PROFILE='DEFAULT';

set head off;
select ' --DEFAULT USERS AND THEIR ACCOUNT STATUS--' from dual;
select 'POINT #3	: DEFAULT USERS CREATED WITH THE DATABASE' from dual;
select 'RULE 		: ALL DEFAULT USERS SHOULD BE IN LOCKED STATE' from dual;
select 'RESOULITION	: LOCK THE DEFAULT USERS AFTER ANALYSING THE USERS WHICH ARE IN OPEN STATE,DISCUSS WITH NAVEEN BEFORE DOING' from dual;
set head on;
select username,account_status,lock_date from dba_users where username in(
'ANONYMOUS',
'CTXSYS',
'DBSNMP',
'DSSYS',
'MDSYS',
'ODM',
'ODM_MTR',
'OLAPSYS',
'ORDPLUGINS',
'ORDSYS',
'OUTLN',
'PERFSTAT',
'REPADMIN',
'SYS',
'SYSTEM',
'TRACESVR',
'WKPROXY',
'WKSYS',
'WMSYS',
'XDB',
'LBACSYS',
'SCOTT',
'BI',
'CTXSYS',
'DIP',
'DMSYS',
'EXFSYS',
'FLOWS_XXXXXX',
'HR',
'IX',
'MDDATA',
'MGMT_VIEW',
'MTSSYS',
'OASPUBLIC',
'OE',
'PM',
'SH',
'SYSMAN',
'TRACESRV',
'WEBSYS',
'WK_PROXY',
'WK_TEST'
);


set head off;
select ' --UTL TO PUBLIC--' from dual;
col  GRANTEE for a20
select 'POINT #4	: UTL PROCEDURES EXECUTE TO PUBLIC' from dual;
select 'RULE 		: UTL_FILE,UTL_HTTP,UTL_TCP,UTL_SMTP' from dual;
select 'RESOULITION	: NEED TO CONTACT WITH APPLICATION TEAM FOR WHAT USERS THE ACCESS FOR THE PROCEDURES' from dual;
select '		  TO BE GIVEN AND THEN AFTER GRANTING WITH VALID REQUEST WE NEED TO REVOKE FROM PUBLIC' from dual;
set head on;
select GRANTEE, OWNER,TABLE_NAME,PRIVILEGE,GRANTABLE from dba_tab_privs where TABLE_NAME in('UTL_FILE','UTL_HTTP','UTL_TCP','UTL_SMTP');

set head off;
select ' --UTL TO OTHER USERS--' from dual;
select 'POINT #5	: UTL PROCEDURES EXECUTE TO OTHERS' from dual;
select 'RULE 		: THESE PERMISIIONS NEEDS A VALID ITSME REQUEST' from dual;
select 'RESOULITION	: IF THE REQUEST IS NOT THERE PLEASE ASK APPLICATION TEAM TO RAISE THE REQUEST AND' from dual;
select '		  IF IT EXIST PLEASE LIST OUT THE REQUEST NUMBER AGAINST EACH USER ' from dual;
set head on;
select GRANTEE, OWNER,TABLE_NAME,PRIVILEGE,GRANTABLE from dba_tab_privs where TABLE_NAME like 'UTL%' and GRANTEE <>'PUBLIC';

set head off;
select ' --UTL_FILE_DIR--' from dual;
select 'POINT #6	: UTL_FILE_DIR PARMETER' from dual;
select 'RULE 		: SHOULD NOT BE SET TO  * ,THIS PARMETER SHOULD BE NULL OR IT SHOULD BE SET AGAINST ANY SPECIFIC DIRECTORY ' from dual;
select 'RESOULITION	: IF * IS OBSERVED THEN GET THE DIRECTORY STRUCTURED FROM WHICH APPLICATION IS ACCESSING THE FILES.' from dual;
select '		  CHANGING THE VALUE OF THIS PARAMETER NEEDS DOWNTIME' from dual;
sho parameter UTL_FILE_DIR

select ' --O7_DICTIONARY_ACCESSIBILITY--' from dual;
select 'POINT #7	: O7_DICTIONARY_ACCESSIBILITY PARMETER' from dual;
select 'RULE 		: SHOULD NOT BE SET TO  TRUE' from dual;
select 'RESOULITION	: SHOULD BE CHANGED TO FALSE' from dual;
sho parameter O7_DICTIONARY_ACCESSIBILITY

select ' --AUDIT_TRAIL--' from dual;
select 'POINT #8	: AUDIT_TRAIL PARMETER' from dual;
select 'RULE 		: SHOULD BE SET TO DB' from dual;
select 'RESOULITION	: IF IT IS NOT SET TO DB CHANGE IT TO DB BY TAKING DOWNTIME' from dual;
 sho parameter audit_trail

select ' --REMOTE OS AUTHENT --' from dual;
select 'POINT #9	: REMOTE OS AUTHENT PARMETER' from dual;
select 'RULE 		: SHOULD NOT BE SET TO  TRUE' from dual;
select 'RESOULITION	: SHOULD BE CHANGED TO FALSE' from dual;
sho parameter remote_os_authent

set head off;
select ' --PUBLIC DB LINKS--' from dual;
col OWNER for a20
col DB_LINK for a50
col HOST for a30
select 'POINT #10	: PUBLIC DB LINKS' from dual;
select 'RULE 		: THERE SHOULD NOT BE ANY PUBLIC DB LINKS' from dual;
select 'RESOULITION	: SHOULD BE UPDATED IN KRD' from dual;
set head on;
select OWNER,DB_LINK,USERNAME,HOST from dba_db_links where OWNER='PUBLIC';



select ' --SYS PRIVS GRANTED WITH ADMIN OPTION--' from dual;

select GRANTEE,PRIVILEGE, ADMIN_OPTION from dba_sys_privs where ADMIN_OPTION='YES' and grantee not in('DBA','SYS') order by grantee;

select ' --TABLES PRIVS GRANTED WITH ADMIN OPTION to PUBLIC--' from dual;

select GRANTEE,OWNER,TABLE_NAME,GRANTOR,PRIVILEGE from dba_tab_privs where GRANTABLE='YES' and owner not like '%SYS%' and GRANTEE='PUBLIC';


select ' --TABLES PRIVS GRANTED WITH ADMIN OPTION OTHER THAN TO PUBLIC--' from dual;


select GRANTEE,OWNER,TABLE_NAME,GRANTOR,PRIVILEGE from dba_tab_privs where GRANTABLE='YES' and GRANTEE<>'PUBLIC';

select ' --ROLES GRANTED WITH ADMIN OPTION--' from dual;

select GRANTEE,GRANTED_ROLE from dba_role_privs where ADMIN_OPTION='YES' and GRANTEE not in ('SYS','DBA','SYSTEM');


create table ttsl_dba_users(username varchar2(50));

insert into ttsl_dba_users values('TCS110580');
insert into ttsl_dba_users values('TCS110562');
insert into ttsl_dba_users values('TCS109850');
insert into ttsl_dba_users values('TCS144852');
insert into ttsl_dba_users values('TCS153368');
insert into ttsl_dba_users values('TCS190308');
insert into ttsl_dba_users values('TCS209746');
insert into ttsl_dba_users values('TCS309519');
insert into ttsl_dba_users values('TCS209755');
insert into ttsl_dba_users values('TCS209736');
insert into ttsl_dba_users values('TCS212177');
insert into ttsl_dba_users values('TCS224164');
insert into ttsl_dba_users values('TCS205488');
insert into ttsl_dba_users values('TCS193396');
insert into ttsl_dba_users values('TCS224166');
insert into ttsl_dba_users values('TCS218805');
insert into ttsl_dba_users values('TCS167031');
insert into ttsl_dba_users values('TCS178869');
insert into ttsl_dba_users values('TCS208267');
insert into ttsl_dba_users values('TCS209752');
insert into ttsl_dba_users values('TCS163479');
insert into ttsl_dba_users values('TCS200078');
insert into ttsl_dba_users values('TCS194271');
insert into ttsl_dba_users values('TCS207721');
insert into ttsl_dba_users values('TCS120348');
insert into ttsl_dba_users values('TCS163521');
insert into ttsl_dba_users values('TCS221784');
insert into ttsl_dba_users values('TCS224292');
insert into ttsl_dba_users values('TCS219852');
insert into ttsl_dba_users values('TCS167141');
insert into ttsl_dba_users values('TCS236666');
insert into ttsl_dba_users values('TCS248136');

commit;



select ' --OUR DBA USERS WHICH DOES NOT EXIST AT ALL--' from dual;
select username from ttsl_dba_users minus select  username from dba_users where username in(select username from ttsl_dba_users);

select ' --TTSL DBA USERS AND THEIR ROLES--' from dual;
select GRANTEE,GRANTED_ROLE from dba_role_privs where GRANTEE in (select username from ttsl_dba_users) order by grantee;

select ' --DBA USERS WITH PROFILE NOT EQUAL TO DBA_SEC--' from dual;
col USERNAME for a30
select USERNAME,PROFILE from dba_users where username in (select GRANTEE from dba_role_privs where GRANTED_ROLE='DBA') and profile<>'DBA_SEC';


select ' --DBA USERS OTHER THAN EXITING DBA USERS--' from dual;
select GRANTEE from dba_role_privs where GRANTED_ROLE='DBA' minus select username from ttsl_dba_users;


drop table ttsl_dba_users;


select ' --IDENTIFYING USERS WITH SYS PRIVS --' from dual;

select GRANTEE,PRIVILEGE from dba_sys_privs 
where 
(PRIVILEGE like '%ANY%' or PRIVILEGE like '%PUBLIC%' or PRIVILEGE like  '%TABLESPACE%'
or privilege in 
('CREATE DATABASE LINK','CREATE USER','DROP USER','RESTRICTED SESSION','CREATE ROLE','ALTER DATABASE','CREATE ROLLBACK SEGMENT','ALTER SYSTEM','EXPORT FULL DATABASE')
or privilege like '%PROFILE%')
and grantee not in (
'ANONYMOUS',
'CTXSYS',
'DBSNMP',
'DSSYS',
'MDSYS',
'ODM',
'ODM_MTR',
'OLAPSYS',
'ORDPLUGINS',
'ORDSYS',
'OUTLN',
'PERFSTAT',
'REPADMIN',
'SYS',
'SYSTEM',
'TRACESVR',
'WKPROXY',
'WKSYS',
'WMSYS',
'XDB',
'LBACSYS',
'SCOTT',
'BI',
'CTXSYS',
'DIP',
'DMSYS',
'EXFSYS',
'FLOWS_XXXXXX',
'HR',
'IX',
'MDDATA',
'MGMT_VIEW',
'MTSSYS',
'OASPUBLIC',
'OE',
'PM',
'SH',
'SYSMAN',
'TRACESRV',
'WEBSYS',
'WK_PROXY',
'WK_TEST',
'DBA'
) and GRANTEE not in (select role from dba_roles) order by privilege;


select ' --USERS GRANTED THE ROLES FOR WHICH SYS-PRIV IS GRANTED--' from dual;

select GRANTEE,GRANTED_ROLE from dba_role_privs  where GRANTED_ROLE in (
select distinct GRANTEE from dba_sys_privs where (PRIVILEGE like '%ANY%' or PRIVILEGE like '%PUBLIC%' or PRIVILEGE like  '%TABLESPACE%'
or privilege in 
('CREATE DATABASE LINK','CREATE USER','DROP USER','RESTRICTED SESSION','CREATE ROLE','ALTER DATABASE','CREATE ROLLBACK SEGMENT','ALTER SYSTEM','EXPORT FULL DATABASE')
or privilege like '%PROFILE%')
and grantee not in (
'ANONYMOUS',
'CTXSYS',
'DBSNMP',
'DSSYS',
'MDSYS',
'ODM',
'ODM_MTR',
'OLAPSYS',
'ORDPLUGINS',
'ORDSYS',
'OUTLN',
'PERFSTAT',
'REPADMIN',
'SYS',
'SYSTEM',
'TRACESVR',
'WKPROXY',
'WKSYS',
'WMSYS',
'XDB',
'LBACSYS',
'SCOTT',
'BI',
'CTXSYS',
'DIP',
'DMSYS',
'EXFSYS',
'FLOWS_XXXXXX',
'HR',
'IX',
'MDDATA',
'MGMT_VIEW',
'MTSSYS',
'OASPUBLIC',
'OE',
'PM',
'SH',
'SYSMAN',
'TRACESRV',
'WEBSYS',
'WK_PROXY',
'WK_TEST',
'DBA'
)
and GRANTEE  in (select role from dba_roles where role not in ('DBA'))
)
and GRANTEE not in (
'ANONYMOUS',
'CTXSYS',
'DBSNMP',
'DSSYS',
'MDSYS',
'ODM',
'ODM_MTR',
'OLAPSYS',
'ORDPLUGINS',
'ORDSYS',
'OUTLN',
'PERFSTAT',
'REPADMIN',
'SYS',
'SYSTEM',
'TRACESVR',
'WKPROXY',
'WKSYS',
'WMSYS',
'XDB',
'LBACSYS',
'SCOTT',
'BI',
'CTXSYS',
'DIP',
'DMSYS',
'EXFSYS',
'FLOWS_XXXXXX',
'HR',
'IX',
'MDDATA',
'MGMT_VIEW',
'MTSSYS',
'OASPUBLIC',
'OE',
'PM',
'SH',
'SYSMAN',
'TRACESRV',
'WEBSYS',
'WK_PROXY',
'WK_TEST',
'DBA'
);

select ' --IDENTIFYING USERS WITH db default ROLES --' from dual;
select GRANTEE,granted_role from dba_role_privs 
where granted_role  in 
('CONNECT',
'RESOURCE',
'SELECT_CATALOG_ROLE',
'EXECUTE_CATALOG_ROLE',
'DELETE_CATALOG_ROLE',
'EXP_FULL_DATABASE',
'IMP_FULL_DATABASE',
'RECOVERY_CATALOG_OWNER',
'GATHER_SYSTEM_STATISTICS',
'OEM_MONITOR')
and grantee not in (
'ANONYMOUS',
'CTXSYS',
'DBSNMP',
'DSSYS',
'MDSYS',
'ODM',
'ODM_MTR',
'OLAPSYS',
'ORDPLUGINS',
'ORDSYS',
'OUTLN',
'PERFSTAT',
'REPADMIN',
'SYS',
'SYSTEM',
'TRACESVR',
'WKPROXY',
'WKSYS',
'WMSYS',
'XDB',
'LBACSYS',
'SCOTT',
'BI',
'CTXSYS',
'DIP',
'DMSYS',
'EXFSYS',
'FLOWS_XXXXXX',
'HR',
'IX',
'MDDATA',
'MGMT_VIEW',
'MTSSYS',
'OASPUBLIC',
'OE',
'PM',
'SH',
'SYSMAN',
'TRACESRV',
'WEBSYS',
'WK_PROXY',
'WK_TEST',
'DBA'
) and GRANTEE not in (select role from dba_roles) order by granted_role;




select ' --IDENTIFYING USERS WITH roles for which db default ROLES have been assigned --' from dual;
select GRANTEE,GRANTED_ROLE from dba_role_privs  where GRANTED_ROLE in (
select distinct GRANTEE from dba_role_privs 
where granted_role  in 
('CONNECT',
'RESOURCE',
'SELECT_CATALOG_ROLE',
'EXECUTE_CATALOG_ROLE',
'DELETE_CATALOG_ROLE',
'EXP_FULL_DATABASE',
'IMP_FULL_DATABASE',
'RECOVERY_CATALOG_OWNER',
'GATHER_SYSTEM_STATISTICS',
'OEM_MONITOR')
and grantee not in (
'ANONYMOUS',
'CTXSYS',
'DBSNMP',
'DSSYS',
'MDSYS',
'ODM',
'ODM_MTR',
'OLAPSYS',
'ORDPLUGINS',
'ORDSYS',
'OUTLN',
'PERFSTAT',
'REPADMIN',
'SYS',
'SYSTEM',
'TRACESVR',
'WKPROXY',
'WKSYS',
'WMSYS',
'XDB',
'LBACSYS',
'SCOTT',
'BI',
'CTXSYS',
'DIP',
'DMSYS',
'EXFSYS',
'FLOWS_XXXXXX',
'HR',
'IX',
'MDDATA',
'MGMT_VIEW',
'MTSSYS',
'OASPUBLIC',
'OE',
'PM',
'SH',
'SYSMAN',
'TRACESRV',
'WEBSYS',
'WK_PROXY',
'WK_TEST',
'DBA'
) and GRANTEE in (select role from dba_roles))
and GRANTEE not in (
'ANONYMOUS',
'CTXSYS',
'DBSNMP',
'DSSYS',
'MDSYS',
'ODM',
'ODM_MTR',
'OLAPSYS',
'ORDPLUGINS',
'ORDSYS',
'OUTLN',
'PERFSTAT',
'REPADMIN',
'SYS',
'SYSTEM',
'TRACESVR',
'WKPROXY',
'WKSYS',
'WMSYS',
'XDB',
'LBACSYS',
'SCOTT',
'BI',
'CTXSYS',
'DIP',
'DMSYS',
'EXFSYS',
'FLOWS_XXXXXX',
'HR',
'IX',
'MDDATA',
'MGMT_VIEW',
'MTSSYS',
'OASPUBLIC',
'OE',
'PM',
'SH',
'SYSMAN',
'TRACESRV',
'WEBSYS',
'WK_PROXY',
'WK_TEST',
'DBA'
);



select ' --PROFILE INFORMATION --' from dual;
select * from dba_profiles order by profile;

select ' --APPLICATION USERS--' from dual;
select USERNAME,ACCOUNT_STATUS,EXPIRY_DATE from dba_users where PROFILE='APPL_SEC';

select ' --PSG USERS--' from dual;
select USERNAME,ACCOUNT_STATUS,EXPIRY_DATE from dba_users where PROFILE='PSG_SEC';


select ' --TTSL USERS--' from dual;
 select USERNAME,ACCOUNT_STATUS,EXPIRY_DATE from dba_users where PROFILE='TTSL_SEC';


select ' --OS USERS--' from dual;
select USERNAME,ACCOUNT_STATUS,EXPIRY_DATE from dba_users where PROFILE='OS_SEC';


select ' --MONITORING USERS--' from dual;
select USERNAME,ACCOUNT_STATUS,EXPIRY_DATE from dba_users where PROFILE='MONITORING_PROFILE';


select ' --LOGON AUDIT TRIGGER STATUS--' from dual;
select OWNER,TRIGGER_NAME,TRIGGER_TYPE,STATUS from dba_triggers where trigger_name like '%LOGON%';


select ' --DDL AUDIT TRIGGER STATUS--' from dual;
select OWNER,TRIGGER_NAME,TRIGGER_TYPE,STATUS from dba_triggers where trigger_name like '%DDL%';

select ' --USERS WITH NO EXPIRY DATE- NEED TO CROSS VERIFY PROFILES--' from dual;
select USERNAME,ACCOUNT_STATUS,EXPIRY_DATE,LOCK_DATE,profile from dba_users where account_status='OPEN' and expiry_date is null;

select ' --USERS WHO HAVE NOT LOGGED IN 45 DAYS- TO BE LOCKED--' from dual;
select USERNAME,ACCOUNT_STATUS,EXPIRY_DATE,LOCK_DATE,profile from dba_users where account_status='OPEN' and expiry_date is not null and  sysdate-expiry_date > 45;

select ' --DBA AND ALL TABLE PRIVS TO PUBLIC' from dual;
select GRANTEE,OWNER,TABLE_NAME,GRANTOR,PRIVILEGE from dba_tab_privs where (TABLE_NAME like 'DBA_%' or TABLE_NAME like 'ALL_%') and grantee='PUBLIC';


select ' --ALL APPL_SEC USERS TOAD ACCESS RESTRICTED--NO ROWS SELECTED' from dual;
select username from dba_users where profile='APPL_SEC' and username in (select upper(USERID) from sys.DB_ACCESS_GRANTED);

select ' --NEED TO REMOVE THIS USER FROM SYS.DB_ACCESS_GRANTED TABLE' from dual;
select upper(USERID) from sys.DB_ACCESS_GRANTED minus select username from dba_users;


























