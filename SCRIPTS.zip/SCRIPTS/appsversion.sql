select release_name from apps.fnd_product_groups;


SELECT substr(a.application_short_name, 1, 5) code,
       substr(t.application_name, 1, 50) application_name,
       p.product_version version
  FROM APPLSYS.fnd_application a,
       APPLSYS.fnd_application_tl t,
       APPLSYS.fnd_product_installations p
 WHERE a.application_id = p.application_id
   AND a.application_id = t.application_id
   AND t.language = USERENV('LANG');