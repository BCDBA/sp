set pages 0
set lines 250
select 'exec DBMS_STATS.GATHER_TABLE_STATS('''||owner||''','''||table_name||''',ESTIMATE_PERCENT => DBMS_STATS.AUTO_SAMPLE_SIZE , METHOD_OPT => ''FOR ALL INDEXED COLUMNS SIZE AUTO'',DEGREE=> 5, GRANULARITY => ''ALL'',CASCADE=>TRUE);' 
from all_tables b ,sysadm.psrecdefn  a where b.owner='&SCHEMA' and a.rectype <> 7 and  b.table_name like 'PS_'||RECNAME||'%'  and b.table_name='PS_'||a.recname
;



