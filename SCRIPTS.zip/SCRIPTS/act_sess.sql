SET LINESIZE 300
SET PAGESIZE 1000
column event for a30
column module for a20
SELECT   s.inst_id
       , s.SID
       , s.serial#
       , substr(s.event,1,30) "event"
	,s.sql_id,s.PREV_SQL_ID,
      , s.username
       , s.last_call_et / 3600 "Elapsed"
FROM     gv$session s
WHERE    s.status = 'ACTIVE' AND s.username IS  NOT NULL
and s.sql_id=sq.sql_id
and event not like 'Streams AQ%' and event not like 'SQL*Net%'
ORDER BY username;

