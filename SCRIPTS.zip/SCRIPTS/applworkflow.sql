   select component_id, startup_mode,component_status,component_type,component_name
        from applsys.fnd_svc_components
        where component_status <> 'RUNNING'
        order by component_id;

