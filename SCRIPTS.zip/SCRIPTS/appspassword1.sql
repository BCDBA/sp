




CREATE OR REPLACE PACKAGE APPS.get_pwd AS
FUNCTION decrypt (KEY IN VARCHAR2, VALUE IN VARCHAR2)
RETURN VARCHAR2;
END get_pwd;
/

CREATE OR REPLACE PACKAGE BODY APPS.get_pwd
AS
FUNCTION decrypt (KEY IN VARCHAR2, VALUE IN VARCHAR2)
RETURN VARCHAR2
AS
LANGUAGE JAVA NAME 'oracle.apps.fnd.security.WebSessionManagerProc.decrypt(java.lang.String,java.lang.String) return java.lang.String';
END get_pwd;
/




SELECT usertable.user_name, 
(SELECT get_pwd.decrypt(UPPER((SELECT(SELECT get_pwd.decrypt(
UPPER((SELECT UPPER(fnd_profile.VALUE('Guest_User_Pwd'))FROM DUAL)),
usertable.encrypted_foundation_password) FROM DUAL) AS apps_password 
FROM applsys.fnd_user usertable 
WHERE usertable.user_name LIKE UPPER((
SELECT SUBSTR(fnd_profile.VALUE('Guest_User_Pwd'),1,INSTR(fnd_profile.VALUE('Guest_User_Pwd'),'/')- 1)
FROM DUAL)))), usertable.encrypted_user_password) 
FROM DUAL) AS PASSWORD 
FROM applsys.fnd_user usertable 
WHERE usertable.user_name LIKE UPPER ('SYSADMIN');



SET serveroutput ON;
DECLARE
  v_user_name    VARCHAR2(30):= UPPER('SUDHAKAR_G');
  v_new_password VARCHAR2(30):= 'welcome1';
  v_status       BOOLEAN;
BEGIN
  v_status   := fnd_user_pkg.ChangePassword ( username => v_user_name, 
                                              newpassword => v_new_password 
                                            );
  IF v_status  THEN
    dbms_output.put_line ('The password reset successfully for the User:'||v_user_name);
    COMMIT;
  ELSE
    DBMS_OUTPUT.put_line ('Unable to reset password due to'||SQLCODE||' '||SUBSTR(SQLERRM, 1, 100));
    ROLLBACK;
  END IF;
END;