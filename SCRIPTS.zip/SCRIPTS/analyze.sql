col table_name format a30
col owner format a20
col tablespace_name format a30
col last_analyzed format a15
select table_name,owner,tablespace_name,LAST_ANALYZED from dba_tables where table_name='&table_name';

col table_name format a30
col owner format a20
col tablespace_name format a30
col last_analyzed format a15
select table_name,INDEX_NAME,owner,tablespace_name,LAST_ANALYZED from dba_INDEXES where table_name='&table_name';

col PARTITION_name format a30
select  OWNER,TABLE_NAME,PARTITION_NAME,NUM_ROWS,BLOCKS,EMPTY_BLOCKS, round(num_rows*avg_row_len/8192) "ACTUAL_BLOCKS" ,
LAST_ANALYZED,GLOBAL_STATS,
USER_STATS,
STALE_STATS,
STATTYPE_LOCKED
from
DBA_TAB_STATISTICS
where table_name='&table_name';



select  OWNER,TABLE_NAME,INDEX_NAME,NUM_ROWS,LEAF_BLOCKS, BLEVEL,
LAST_ANALYZED,GLOBAL_STATS,
USER_STATS,
STALE_STATS
from
DBA_IND_STATISTICS
where table_name='&table_name';




