select  /*+ rule */  sid,inst_id from gv$access where object=upper('&object_name')
/
