col module for a35 trunc
col ARGUMENT_TEXT for a40 noprint
col action for a20 trunc noprint
col uname for a15 trunc
col event for a40 trunc
col sid head "Sid" form 999999 trunc

select request_id,PARENT_REQUEST_ID ,concurrent_program_id  PROG_ID,s.inst_id,s.sid sid,s.serial# serial,to_char(logon_time,'dd/mm hh24:mi') dt,argument_text,
s.module module,s.action action,user_name uname,s.event,s.sql_id sql_id
from  gv$session s,gv$process p,apps.fnd_concurrent_requests fnd,apps.fnd_user fndu
where p.inst_id = s.inst_id
and p.addr = s.paddr 
and p.spid = fnd.oracle_process_id 
and  fnd.requested_by = fndu.user_id 
and	 fnd.status_code = 'R'
and	 fnd.phase_code = 'R'
order by 1
/
