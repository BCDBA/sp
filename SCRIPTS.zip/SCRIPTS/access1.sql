select  /*+ rule */  sid from v$access where object like upper('%&object_name%')
/