select * From table(dbms_xplan.display_awr('&sqlid'))
/