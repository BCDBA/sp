set autotrace traceonly exp stat
set arraysize 5000