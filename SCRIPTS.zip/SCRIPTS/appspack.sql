SELECT
         FCR.REQUEST_ID
       , FCPV.USER_CONCURRENT_PROGRAM_NAME
       , FCPV.CONCURRENT_PROGRAM_NAME
       , FCPV.CONCURRENT_PROGRAM_ID
       , FCR.STATUS_CODE
       , FCR.PHASE_CODE
FROM
         FND_CONCURRENT_PROGRAMS_VL FCPV
       , FND_EXECUTABLES            FE
       , SYS.DBA_DEPENDENCIES       DD
       , FND_CONCURRENT_REQUESTS    FCR
WHERE
         FCPV.EXECUTABLE_ID                                                                = FE.EXECUTABLE_ID
         AND FE.EXECUTION_METHOD_CODE                                                      = 'I'
         AND SUBSTR(FE.EXECUTION_FILE_NAME,1,INSTR(FE.EXECUTION_FILE_NAME, '.', 1, 1) – 1) = UPPER(DD.NAME)
         AND DD.REFERENCED_TYPE IN ('VIEW'
                                  , 'TABLE'
                                  , 'TRIGGER'
                                  , 'PACKAGE') — add as required –AND referenced_owner = 'XXCUS'
         AND DD.REFERENCED_NAME                                                        = UPPER('&Package_name')
         AND FCR.CONCURRENT_PROGRAM_ID                                                 = FCPV.CONCURRENT_PROGRAM_ID
         AND fcr.phase_code NOT IN ( 'C'
                                  , 'P')
;