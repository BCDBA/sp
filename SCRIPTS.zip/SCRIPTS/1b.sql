select 'alter index '||owner||'.'||index_name||' noparallel ;'
from dba_indexes  where status='UNUSABLE'  and table_name in (select segment_name from dba_segments where bytes/1024/1024/1024 <1) 
/