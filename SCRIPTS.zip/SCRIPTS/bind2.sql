set lines 300 pages 5000
col DECLARE_VAR for a40
select DISTINCT child_number, 'VAR ' || SUBSTR(NAME,2) || CASE WHEN DATATYPE_STRING='DATE' THEN ' VARCHAR2(20)' ELSE ' ' || DATATYPE_STRING END || ';' || CHR(10) ||
        'EXEC ' || NAME || ':=' || CASE WHEN DATATYPE_STRING='NUMBER' then nvl(VALUE_STRING,'NULL') ELSE decode(value_string,null,'NULL','''' || nvl(VALUE_STRING,'NULL') || '''' ) || ';' END "DECLARE_VAR"
from v$sql_bind_capture where sql_id='&sqlid' order by child_number;