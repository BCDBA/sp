select 'alter index '||owner||'.'||index_name||' rebuild tablespace NEW_INDEX parallel 6;'
from dba_indexes  where status='UNUSABLE'  and table_name in (select segment_name from dba_segments where bytes/1024/1024/1024 <1)
/