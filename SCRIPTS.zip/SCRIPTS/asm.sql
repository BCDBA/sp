select name, total_mb, free_mb, total_mb - free_mb "used_mb" from v$asm_diskgroup;

col PATH form a60;

select GROUP_NUMBER,DISK_NUMBER,MOUNT_STATUS,HEADER_STATUS,NAME,PATH from v$asm_disk;