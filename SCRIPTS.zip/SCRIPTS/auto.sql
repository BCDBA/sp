
select file_name, bytes/(1024*1024*1024), maxbytes/(1024*1024*1024),  increment_by*((bytes/(1024*1024*1024))/blocks) "INCREMENT",  
(maxbytes/(1024*1024*1024))-(bytes/(1024*1024*1024)) remaining, 
((maxbytes/(1024*1024*1024))-(bytes/(1024*1024*1024)))/(increment_by*((bytes/(1024*1024*1024))/blocks)) EXTENSIONS  
from dba_data_files  where autoextensible = 'YES';

select file_name,bytes, maxbytes,increment_by*(bytes/blocks) "INCREMENT",maxbytes-bytes remaining, (maxbytes-bytes)/(increment_by*(bytes/blocks)) 
EXTENSIONS  from dba_data_files  where autoextensible = 'YES';