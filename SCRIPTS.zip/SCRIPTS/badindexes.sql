select owner||'.'||index_name||' STATUS='||status status
from dba_indexes where status='UNUSABLE'
union all
select owner||'.'||index_name||' DOMIDX_STATUS='||domidx_status status
from dba_indexes where domidx_status='IDXTYP_INVLD'
union all
select owner||'.'||index_name||' DOMIDX_OPSTATUS='||domidx_opstatus status
from dba_indexes where domidx_opstatus='FAILED'
union all
select owner||'.'||index_name||' FUNCIDX_STATUS='||funcidx_status status
from dba_indexes where funcidx_status='DISABLED';