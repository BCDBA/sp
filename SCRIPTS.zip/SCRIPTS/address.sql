select SID,sql_address from v$session where sql_address='&address'
/