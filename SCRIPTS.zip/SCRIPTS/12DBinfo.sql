select name from v$databbase;

select name,open_mode from v$pdbs;