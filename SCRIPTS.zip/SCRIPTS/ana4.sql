select 'exec dbms_stats.gather_table_stats(ownname=>'''||owner||''',tabname=>'''||table_name||''',cascade=>true,granularity=>'''||'ALL'||''',estimate_percent=>30,DEGREE =>8);' 
from dba_tables where owner in ('MKTDS','LPLANDS','PSOPSDS');

