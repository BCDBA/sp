Set Head On
Column Since Format A23
Column PMON  Format A6
Column Status Heading Status
Column Since  Heading Since
Column PMON   Heading Method
Column Status format A47

Select ('Internal Conc Manager is running on - ' || node_name) Status,
        To_Char(P.Last_Update_Date, 'DD-MON-YY HH:MI:SS AM') Since,
        Profile_Option_Value PMON
  from  APPS.Fnd_Concurrent_Processes P, APPS.FND_V$Process, APPS.Fnd_Profile_Options PO,
        APPS.Fnd_Profile_Option_Values POV
 where  ( ( Profile_Option_Value <> 'OS' And
           (OS_Process_Id     = Spid And Oracle_Process_Id = pid  ) And
           (Concurrent_Queue_Id  = 1 And Queue_Application_ID = 0 ))
       OR ( Profile_Option_Value = 'OS' And
            OS_Process_ID = Spid And
           (Concurrent_Queue_Id  = 1 And Queue_Application_ID = 0 )) )
    And ( PO.Profile_Option_ID = POV.Profile_Option_ID And
          PO.Application_ID    = POV.Application_ID )
    And Profile_Option_Name    = 'CONC_PMON_METHOD'
    And Process_Status_Code = 'A' ;

Set Head Off
Column Logfile_Name Format A50
Column Logfile_name Heading Logfile

Select 'Log File - ' || Logfile_Name
  from  APPS.Fnd_Concurrent_Processes P, APPS.FND_V$Process, APPS.Fnd_Profile_Options PO,
        APPS.Fnd_Profile_Option_Values POV
 where  ( ( Profile_Option_Value <> 'OS' And
           (OS_Process_Id     = Spid And Oracle_Process_Id = pid  ) And
           (Concurrent_Queue_Id  = 1 And Queue_Application_ID = 0 ))
       OR ( Profile_Option_Value = 'OS' And
            OS_Process_ID = Spid And
           (Concurrent_Queue_Id  = 1 And Queue_Application_ID = 0 )) )
    And ( PO.Profile_Option_ID = POV.Profile_Option_ID And
          PO.Application_ID    = POV.Application_ID )
    And Profile_Option_Name    = 'CONC_PMON_METHOD'
    And Process_Status_Code = 'A' ;
