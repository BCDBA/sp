select  (extract( day from retention) *24*60+ extract( hour from retention) *60+   extract( minute from retention ))/(24*60) "Days_Of_Metadata"
from dba_hist_wr_control;
