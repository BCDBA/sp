
set pages 20000;
col application_id for 9999;
col application_name for A50;
col status for A13;
col application_short_name for A10;
select fa.application_id,
fa.application_short_name,
fpi.status,
fatl.application_name
from
fnd_product_installations fpi,
fnd_application fa,
fnd_application_tl fatl
where
(
fa.application_id = fpi.application_id and
fa.application_id = fatl.application_id and
fatl.language = 'US'
)
order by fa.application_short_name;


SELECT a.application_name,a.product_code,
DECODE (b.status, 'I', 'Installed', 'S', 'Shared', 'N/A') status,
 patch_level  FROM apps.fnd_application_vl a,
 apps.fnd_product_installations b
 WHERE a.application_id = b.application_id
  and b.status='I'
  order by product_code asc;














