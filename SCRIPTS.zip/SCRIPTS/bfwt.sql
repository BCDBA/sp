select count(*) number_of_waiters 
from v$session_wait w, v$latch l 
where w.wait_time = 0 
and  w.event     = 'latch free' 
and  w.p2        = l.latch# 
and  l.name      like 'library%'
/


select
  w.class  block_class,
  w.count  total_waits,
  w.time  time_waited
from
  sys.v_$waitstat  w
where
  w.count > 0
order by 3 desc
/
select
  d.tablespace_name,
  sum(x.count)  total_waits,
  sum(x.time)  time_waited
from
  sys.x_$kcbfwait  x,
  sys.dba_data_files  d
where
  x.inst_id = userenv('Instance') and
  x.count > 0 and
  d.file_id = x.indx + 1
group by
  d.tablespace_name
order by 3 desc
/


