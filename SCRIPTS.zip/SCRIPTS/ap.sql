set lines 200
set pages 1000
select * from table(dbms_xplan.display_cursor('&sql_id',null,format => 'ADVANCED'))

--set lines 200
set pages 1000
select plan_table_output from table(dbms_xplan.display_cursor('&sql_id'))
/