select status,client_name from dba_autotask_client group by status,client_name;


select status from dba_autotask_client where client_name = 'auto space advisor';
select status from dba_autotask_client where client_name = 'sql tuning advisor';
select status from dba_autotask_client where client_name = 'auto optimizer stats collection';
