select patch_name, last_update_date from applsys.ad_applied_patches where patch_name='&PATCHNAME';

select bug_number,last_update_date from applsys.ad_bugs where bug_number='&BUGnum';         

---select  bug_number,last_update_date from ad_bugs where trunc(LAST_UPDATE_DATE) >= '13-JUN-2011'



---select  PATCH_NAME,last_update_date from ad_applied_patches where trunc(LAST_UPDATE_DATE) >= '08-JUN-2011'