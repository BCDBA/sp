create user  APPUID identified by ttsl#1234;
alter user  APPUID DEFAULT TABLESPACE USERS ;
alter user  APPUID TEMPORARY TABLESPACE TEMP;
grant create session to APPUID ;

alter user  APPUID  profile APPL_SEC;

alter user APPUID account lock;