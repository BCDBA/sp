SYS:AISPRD> select 'analyze '||object_type||' '||owner||'.'||object_name||' estimate statistics sample 10 percent ;'
  2  from dba_objects
  3  where
  4  owner not in('SYS','SYSTEM','OUTLN','TRACESVR','DBSNMP','PERFSTAT')
  5  and object_type ='TABLE';
