column service_handle form a30;
column developer_parameters form a60;


SELECT service_id, service_handle, developer_parameters
FROM fnd_cp_services
WHERE service_id in (SELECT manager_type FROM fnd_concurrent_queues);



SELECT service_id, service_handle, developer_parameters
FROM fnd_cp_services
WHERE service_id = (SELECT manager_type FROM fnd_concurrent_queues WHERE concurrent_queue_name = '&QUEUENAME');