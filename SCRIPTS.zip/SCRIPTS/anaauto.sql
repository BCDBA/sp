select 'exec dbms_stats.gather_table_stats(ownname=>'''||owner||''',tabname=>'''||table_name||''',cascade=>true,granularity=>'''||'ALL'||''',estimate_percent => DBMS_STATS.AUTO_SAMPLE_SIZE,DEGREE =>8);' 
from dba_tables where
table_name like '%&TABLE_NAME%' and owner= '&OWNER';