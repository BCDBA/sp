set pages 300
set lines 300
col name for a20

select name,total_mb/1024 "Total(GB)",free_mb/1024 "Free(GB)" from v$asm_diskgroup;
exit;

