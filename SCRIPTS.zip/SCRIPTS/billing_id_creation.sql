spool d:/billing.log
conn tcs178869/praveen#8869@bpadmprd11
select * from global_name;
@billing_ID


conn tcs178869/praveen#8869@bpcatprd11
select * from global_name;
@billing_ID


conn tcs178869/praveen#8869@bpapprd11
select * from global_name;
@billing_ID


conn tcs178869/praveen#8869@bptnprd11
select * from global_name;
@billing_ID


conn tcs178869/praveen#8869@bpmhprd11
select * from global_name;

@billing_ID


conn tcs178869/praveen#8869@bpgjprd11
select * from global_name;

@billing_ID


conn tcs178869/praveen#8869@bpkaprd11
select * from global_name;

@billing_ID


conn tcs178869/praveen#8869@bpdlprd11
select * from global_name;

@billing_ID


conn tcs178869/praveen#8869@bpnatprd11
select * from global_name;

@billing_ID


conn tcs178869/praveen#8869@bppbprd11
select * from global_name;

@billing_ID


conn tcs178869/praveen#8869@bpupprd11
select * from global_name;

@billing_ID


conn tcs178869/praveen#8869@bpbhprd11
select * from global_name;

@billing_ID

conn tcs178869/praveen#8869@BPNEPRD
select * from global_name;

@billing_ID
